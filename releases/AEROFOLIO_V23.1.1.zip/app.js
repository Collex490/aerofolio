
window.addEventListener("error", (event) => {
  console.error("AEROFOLIO JavaScript error:", event.error || event.message);
  const existing = document.getElementById("jsErrorBanner");
  if (existing) return;
  const banner = document.createElement("div");
  banner.id = "jsErrorBanner";
  banner.style.cssText = [
    "position:fixed","left:250px","right:20px","bottom:20px","z-index:99999",
    "background:#8f2020","color:white","padding:12px 16px","border-radius:10px",
    "font:600 13px system-ui","box-shadow:0 8px 30px rgba(0,0,0,.25)"
  ].join(";");
  banner.textContent = "AEROFOLIO Fehler: " + (event.message || "Unbekannter JavaScript-Fehler");
  document.body.appendChild(banner);
});


const canvas = document.getElementById("portraitCanvas");
if (!canvas) {
  throw new Error("portraitCanvas wurde nicht gefunden");
}
const ctx = canvas.getContext("2d");
if (!ctx) {
  throw new Error("2D-Canvas-Kontext konnte nicht erstellt werden");
}

const demoPlanes = [
  {id:"EK46", airline:"Emirates", type:"Airbus A380-800", icaoType:"A388", reg:"A6-EVS", altitude:"10.620 m", route:"DXB → FRA", accent:"#f4eee1"},
  {id:"SQ325", airline:"Singapore Airlines", type:"Boeing 777-300ER", icaoType:"B77W", reg:"9V-SWV", altitude:"10.970 m", route:"SIN → FRA", accent:"#f0d089"},
  {id:"LH441", airline:"Lufthansa", type:"Airbus A350-900", icaoType:"A359", reg:"D-AIXN", altitude:"11.280 m", route:"FRA → IAH", accent:"#f4eee1"},
  {id:"AF1519", airline:"Air France", type:"Airbus A320-200", icaoType:"A320", reg:"F-GKXM", altitude:"9.450 m", route:"CDG → FRA", accent:"#f4eee1"},
  {id:"UPS202", airline:"UPS Airlines", type:"Boeing 767-300F", icaoType:"B763", reg:"N347UP", altitude:"9.140 m", route:"CGN → EMA", accent:"#f0d089"},
  {id:"CLX610", airline:"Cargolux", type:"Boeing 747-8F", icaoType:"B748", reg:"LX-VCC", altitude:"10.360 m", route:"LUX → HKG", accent:"#f4eee1"}
];
let planes = [...demoPlanes];

const LOCAL_API = "/api/live";

const styles = [{id:"vintage", name:"Vintage Poster", desc:"Standard"}];

const state = {
  selected: ["EK46","SQ325","LH441"],
  style: "vintage",
  artScale: 1.12,
  artOffsetX: 0,
  artOffsetY: 0,
  planeLayouts: {},
  ditherMode: "noise",
  ditherStrength: 0.24,
  showAirlineOnAircraft: true,
  location: "Idstein-Wörsdorf",
  lat: "50.223",
  lon: "8.229",
  radius: 25,
  bgColor: "#b72618",
  textColor: "#f4eee1",
  font: "Georgia",
  texts: {
    eyebrow:{label:"Kopfzeile", value:"AEROFOLIO", visible:true},
    title:{label:"Titel", value:"DER HIMMEL ÜBER", visible:true, x:0, y:0, size:38},
    location:{label:"Standorttext", value:"IDSTEIN-WÖRSDORF", visible:true, x:0, y:0, size:58},
    coords:{label:"Koordinaten", value:"50.223° N   8.229° E", visible:true, x:0, y:0, size:24},
    date:{label:"Datum", value:new Date().toLocaleDateString("de-DE",{day:"2-digit",month:"short",year:"numeric"}).toUpperCase(), visible:true},
    quote:{label:"Zitat", value:"ÜBER DEN WOLKEN MUSS DIE FREIHEIT WOHL GRENZENLOS SEIN.", visible:true},
    author:{label:"Autor", value:"REINHARD MEY", visible:true}
  }
};





// V17: no procedural aircraft drawings.
// Aircraft artwork must come from the local PNG/WebP image library.

const vintageProfileCache=new Map();

function vintageProfileUrl(plane){
  const type=encodeURIComponent((plane?.icaoType || plane?.type || "").toUpperCase());
  return `/api/vintage-profile?type=${type}`;
}

function loadVintageProfile(plane){
  const key=`${plane?.icaoType || plane?.type || ""}`;
  if(vintageProfileCache.has(key)) return vintageProfileCache.get(key);
  const promise=new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>resolve(img);
    img.onerror=()=>reject(new Error("curated vintage profile missing"));
    img.src=vintageProfileUrl(plane);
  });
  vintageProfileCache.set(key,promise);
  return promise;
}

async function drawVintageProfile(plane,cx,cy,maxW,maxH){
  const requestedPlane = state.showAirlineOnAircraft
    ? plane
    : {...plane, airline:"", operator:""};

  try{
    const img=await loadVintageProfile(requestedPlane);
    const scale=Math.min(maxW/(img.naturalWidth||img.width),maxH/(img.naturalHeight||img.height));
    const w=(img.naturalWidth||img.width)*scale;
    const h=(img.naturalHeight||img.height)*scale;
    const left=cx-w/2;
    const top=cy-h/2;
    ctx.drawImage(img,left,top,w,h);

    // Return the rendered rectangle so labels can be anchored to the
    // actual aircraft position and size. This keeps the information block
    // attached when a plane is moved or scaled.
    return {left, top, right:left+w, bottom:top+h, width:w, height:h, cx, cy};
  }catch(err){
    return null;
  }
}

function setProviderStatus(provider, kind, text){
  const id = provider === "fp" ? "fpProviderStatus" : "adsbProviderStatus";
  const el = document.getElementById(id);
  if(!el) return;
  el.className = "";
  if(kind) el.classList.add(`provider-${kind}`);
  el.textContent = text;
}

function setActiveProvider(text){
  const el = document.getElementById("activeProvider");
  if(el) el.textContent = text || "–";
}

function setLiveStatus(kind, title, info){
  const dot=document.getElementById("liveDot");
  dot.className="live-dot"+(kind?` ${kind}`:"");
  document.getElementById("liveStatus").textContent=title;
  document.getElementById("liveInfo").textContent=info;
}

function cleanCallsign(value){
  return (value || "").trim().replace(/\s+/g,"");
}

function feetToMeters(ft){
  const n=Number(ft);
  if(!Number.isFinite(n)) return "–";
  return `${(Math.round((n * 0.3048) / 10) * 10).toLocaleString("de-DE")} m`;
}

function altitudeLabel(ac){
  let alt=ac.alt_baro ?? ac.alt_geom;
  if(alt==="ground") return "Boden";
  const n=Number(alt);
  if(!Number.isFinite(n)) return "–";
  return `${Math.round(n*0.3048).toLocaleString("de-DE")} m`;
}

function distanceKm(lat1,lon1,lat2,lon2){
  const r=6371;
  const dLat=(lat2-lat1)*Math.PI/180;
  const dLon=(lon2-lon1)*Math.PI/180;
  const a=Math.sin(dLat/2)**2+
    Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return 2*r*Math.asin(Math.sqrt(a));
}

function updateQueryCoordinates(){
  const el=document.getElementById("queryCoordinates");
  if(!el) return;
  const lat=Number(state.lat);
  const lon=Number(state.lon);
  if(Number.isFinite(lat) && Number.isFinite(lon)){
    el.textContent=`${lat.toFixed(4)}, ${lon.toFixed(4)}`;
  }else{
    el.textContent="–";
  }
}

async function fetchLocalLive(lat, lon, radiusKm){
  const url=`${LOCAL_API}?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&radius_km=${encodeURIComponent(radiusKm)}`;
  const response=await fetch(url,{headers:{"Accept":"application/json"}});
  if(!response.ok){
    let detail="";
    try{
      const body=await response.json();
      detail=body?.error ? `: ${body.error}` : "";
    }catch{}
    throw new Error(`HTTP ${response.status}${detail}`);
  }
  return response.json();
}

function backendAircraftToPlane(ac){
  return {
    id:cleanCallsign(ac.callsign) || (ac.hex || "UNKNOWN").toUpperCase(),
    hex:(ac.hex || "").toLowerCase(),
    airline:ac.operator || "Betreiber unbekannt",
    type:ac.type || "Flugzeug",
    icaoType:ac.type || "",
    family:ac.family || "generic",
    reg:ac.registration || (ac.hex || "").toUpperCase(),
    altitude:ac.altitude_m == null ? "–" : `${Math.round(ac.altitude_m).toLocaleString("de-DE")} m`,
    route:ac.route || "Route unbekannt",
    lat:Number(ac.lat),
    lon:Number(ac.lon),
    distance:Number(ac.distance_km),
    source:ac.source || "merged",
    sources:Array.isArray(ac.sources) ? ac.sources : [ac.source || "merged"],
    accent:"#f4eee1"
  };
}

async function loadLiveAircraft(){
  setLiveStatus("loading","Live-Abfrage gestartet","ADSB.lol wird abgefragt …");

  const lat=Number(state.lat), lon=Number(state.lon);
  const radiusKm=Number(state.radius);
  if(!Number.isFinite(lat) || !Number.isFinite(lon)){
    setLiveStatus("error","Standort ungültig","Bitte Koordinaten prüfen.");
    return;
  }

  updateQueryCoordinates();
  setActiveProvider("ADSB.lol");
  setProviderStatus("adsb","loading","Wird abgefragt …");

  try{
    const data=await fetchLocalLive(lat,lon,radiusKm);
    const adsb=data.providers?.adsb_lol || {};
    if(adsb.ok){
      setProviderStatus("adsb",adsb.count>0?"ok":"empty",adsb.count>0?`${adsb.count} Flugzeuge`:"Keine Treffer");
    }else{
      setProviderStatus("adsb","error",adsb.error || "Fehler");
    }
    planes=(data.aircraft || []).map(backendAircraftToPlane);
    if(planes.length){
      state.selected=planes.slice(0,Math.min(3,planes.length)).map(p=>p.id);
      renderPlaneList(); safeRenderPortrait();
      setLiveStatus("ok","Live-Daten geladen",`${planes.length} Flugzeuge · ${new Date().toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"})}`);
    }else{
      state.selected=[]; renderPlaneList(); safeRenderPortrait();
      setLiveStatus("ok","Keine Live-Flugzeuge gefunden","Im gewählten Radius wurden aktuell keine ADS-B-Positionsdaten gefunden.");
    }
  }catch(err){
    console.error(err);
    setProviderStatus("adsb","error","Backend nicht erreichbar");
    setLiveStatus("error","Live-Abruf fehlgeschlagen",`${err.message}. Läuft die App über start.bat?`);
  }
}

function useDemoData(){
  planes=[...demoPlanes];
  state.selected=["EK46","SQ325","LH441"].filter(id=>planes.some(p=>p.id===id));
  renderPlaneList(); safeRenderPortrait();
  setProviderStatus("adsb","","Nicht geprüft"); setActiveProvider("ADSB.lol");
  setLiveStatus("","Testdaten aktiv","Kein Live-Abruf.");
}



function safeRenderPortrait(){
  Promise.resolve(renderPortrait()).catch(err=>{
    console.error("AEROFOLIO render error:", err);
    window.dispatchEvent(new ErrorEvent("error", {
      message: err?.message || "Poster konnte nicht gerendert werden",
      error: err
    }));
  });
}

function renderPlaneList(){
  const list = document.getElementById("planeList");
  list.innerHTML = "";
  planes.forEach(p=>{
    const card=document.createElement("label");
    const checked=state.selected.includes(p.id);
    card.className="plane-card"+(checked?" selected":"");
    card.innerHTML=`
      <div class="plane-icon">✈</div>
      <div class="plane-main">
        <strong>${p.id}</strong>
        <small>${p.airline}<br>${p.type}</small>
        <span class="source-tag">${p.source==="adsb.lol" ? "ADSB.LOL" : "DEMO"}</span>
      </div>
      <div class="plane-meta">${p.altitude}<br>${p.reg}${Number.isFinite(p.distance)?`<br>${p.distance.toFixed(1)} km`:``}</div>
      <input type="checkbox" ${checked?"checked":""} style="grid-column:1/-1;justify-self:end">
    `;
    const cb=card.querySelector("input");
    cb.addEventListener("change",()=>{
      if(cb.checked){
        if(state.selected.length>=4){ cb.checked=false; alert("Maximal 4 Flugzeuge pro Poster."); return; }
        state.selected.push(p.id);
      } else {
        state.selected=state.selected.filter(id=>id!==p.id);
      }
      renderPlaneList(); safeRenderPortrait();
    });
    list.appendChild(card);
  });
  document.getElementById("selectedCount").textContent=`${state.selected.length}/4`;
  renderPlaneLayoutControls();
}

function renderStyles(){ state.style="vintage"; }



function getPlaneLayout(id, index=0, count=1){
  if(!state.planeLayouts[id]){
    const defaultGap=count===2 ? 350 : count===3 ? 275 : count>=4 ? 225 : 0;
    state.planeLayouts[id]={x:0,y:0,scale:1,textPos:"tail",textX:0,textY:0,textGap:18,gap:defaultGap || 225};
  }
  return state.planeLayouts[id];
}

function renderPlaneLayoutControls(){
  const box=document.getElementById("planeLayoutControls");
  if(!box) return;
  box.innerHTML="";
  const selectedPlanes=state.selected.map(id=>planes.find(p=>p.id===id)).filter(Boolean);
  if(!selectedPlanes.length){
    box.innerHTML='<p class="muted">Wähle zuerst ein Flugzeug aus.</p>';
    return;
  }

  selectedPlanes.forEach((p,index)=>{
    const layout=getPlaneLayout(p.id,index,selectedPlanes.length);
    const card=document.createElement("div");
    card.className="plane-layout-card";
    card.innerHTML=`
      <div class="plane-layout-head">
        <strong>${p.id}</strong>
        <small>${p.icaoType || p.type || "Flugzeug"}</small>
      </div>
      <label class="plane-layout-field">
        <span>Links / rechts <b data-val="x">${layout.x}</b></span>
        <input data-key="x" type="range" min="-220" max="220" step="5" value="${layout.x}">
      </label>
      <label class="plane-layout-field">
        <span>Hoch / runter <b data-val="y">${layout.y}</b></span>
        <input data-key="y" type="range" min="-100" max="100" step="5" value="${layout.y}">
      </label>
      <label class="plane-layout-field">
        <span>Größe <b data-val="scale">${Math.round(layout.scale*100)}%</b></span>
        <input data-key="scale" type="range" min="70" max="140" step="2" value="${Math.round(layout.scale*100)}">
      </label>
      <label class="plane-layout-field select-field">
        <span>Info-Text · am Flugzeug angepinnt</span>
        <select data-key="textPos">
          <option value="tail" ${layout.textPos==="tail"?"selected":""}>am Heck</option>
          <option value="nose" ${layout.textPos==="nose"?"selected":""}>an der Nase</option>
          <option value="below" ${layout.textPos==="below"?"selected":""}>unter dem Flugzeug</option>
          <option value="off" ${layout.textPos==="off"?"selected":""}>ausblenden</option>
        </select>
      </label>
      <label class="plane-layout-field">
        <span>Text-Abstand <b data-val="textGap">${layout.textGap ?? 18}px</b></span>
        <input data-key="textGap" type="range" min="4" max="80" step="2" value="${layout.textGap ?? 18}">
      </label>
      <label class="plane-layout-field">
        <span>Text links / rechts <b data-val="textX">${layout.textX || 0}</b></span>
        <input data-key="textX" type="range" min="-180" max="180" step="5" value="${layout.textX || 0}">
      </label>
      <label class="plane-layout-field">
        <span>Text hoch / runter <b data-val="textY">${layout.textY || 0}</b></span>
        <input data-key="textY" type="range" min="-100" max="120" step="5" value="${layout.textY || 0}">
      </label>
      <label class="plane-layout-field">
        <span>Abstand danach <b data-val="gap">${layout.gap}px</b></span>
        <input data-key="gap" type="range" min="120" max="380" step="5" value="${layout.gap}">
      </label>
    `;

    card.querySelectorAll('input[type="range"]').forEach(input=>{
      input.addEventListener("input",()=>{
        const key=input.dataset.key;
        const v=Number(input.value);
        if(key==="scale") layout.scale=v/100;
        else layout[key]=v;
        const out=card.querySelector(`[data-val="${key}"]`);
        if(out) out.textContent=key==="scale" ? `${v}%` : (key==="gap" || key==="textGap") ? `${v}px` : `${v}`;
        safeRenderPortrait();
      });
    });
    card.querySelector('select[data-key="textPos"]').addEventListener("change",e=>{
      layout.textPos=e.target.value;
      safeRenderPortrait();
    });
    box.appendChild(card);
  });
}

function drawPlaneInfo(p, bounds, layout, fg){
  const pos=layout.textPos || "tail";
  if(pos==="off" || !bounds) return;

  const textGap=Number.isFinite(layout.textGap) ? layout.textGap : 18;
  const textX=layout.textX || 0;
  const textY=layout.textY || 0;
  let x=bounds.left, align="left", baseY=bounds.bottom + textGap;

  // The anchor is derived from the rendered aircraft rectangle, not from
  // the row position. Therefore translation and scaling of the aircraft
  // automatically move the label with it. Fine offsets remain available.
  if(pos==="nose"){
    x=bounds.right; align="right";
  }else if(pos==="below"){
    x=bounds.cx; align="center";
  }

  x += textX;
  baseY += textY;

  if(state.showAirlineOnAircraft && p.airline){
    drawText(p.airline,x,baseY,18,700,align,fg);
    baseY+=25;
  }
  drawText(`${p.id} · ${p.type || "Typ unbekannt"} · ${p.reg || "–"}`,x,baseY,15,500,align,fg);
  drawText(`${p.altitude} · ${p.route || "Route unbekannt"}`,x,baseY+22,14,500,align,fg);
}

function renderTextControls(){
  const box=document.getElementById("textControls");
  box.innerHTML="";
  const movableKeys=new Set(["title","location","coords"]);

  Object.entries(state.texts).forEach(([key,obj])=>{
    const row=document.createElement("div");
    row.className="text-row";
    row.innerHTML=`
      <div class="text-row-top">
        <strong>${obj.label}</strong>
        <label><input type="checkbox" ${obj.visible?"checked":""}> anzeigen</label>
      </div>
      ${key==="quote" ? `<textarea>${obj.value}</textarea>` : `<input type="text" value="${obj.value.replaceAll('"','&quot;')}">`}
      ${movableKeys.has(key) ? `
        <div class="title-layout-controls">
          <label class="plane-layout-field">
            <span>Links / rechts <b data-text-val="x">${obj.x || 0}</b></span>
            <input data-text-key="x" type="range" min="-300" max="300" step="5" value="${obj.x || 0}">
          </label>
          <label class="plane-layout-field">
            <span>Hoch / runter <b data-text-val="y">${obj.y || 0}</b></span>
            <input data-text-key="y" type="range" min="-250" max="250" step="5" value="${obj.y || 0}">
          </label>
          <label class="plane-layout-field">
            <span>Größe <b data-text-val="size">${obj.size || (key==="location"?58:key==="title"?38:24)}px</b></span>
            <input data-text-key="size" type="range"
              min="${key==="location"?24:key==="title"?18:12}"
              max="${key==="location"?90:key==="title"?70:48}"
              step="1"
              value="${obj.size || (key==="location"?58:key==="title"?38:24)}">
          </label>
          <button type="button" class="ghost mini title-reset-btn">Position zurücksetzen</button>
        </div>
      ` : ""}
    `;

    const toggle=row.querySelector('input[type="checkbox"]');
    const input=row.querySelector(key==="quote"?"textarea":'input[type="text"]');
    toggle.addEventListener("change",()=>{obj.visible=toggle.checked;safeRenderPortrait();});
    input.addEventListener("input",()=>{obj.value=input.value;safeRenderPortrait();});

    if(movableKeys.has(key)){
      row.querySelectorAll('input[data-text-key]').forEach(slider=>{
        slider.addEventListener("input",()=>{
          const prop=slider.dataset.textKey;
          const value=Number(slider.value);
          obj[prop]=value;
          const out=row.querySelector(`[data-text-val="${prop}"]`);
          if(out) out.textContent=prop==="size" ? `${value}px` : `${value}`;
          safeRenderPortrait();
        });
      });

      const reset=row.querySelector(".title-reset-btn");
      reset.addEventListener("click",()=>{
        const defaults={
          title:{x:0,y:0,size:38},
          location:{x:0,y:0,size:58},
          coords:{x:0,y:0,size:24}
        }[key];
        Object.assign(obj,defaults);
        row.querySelector('input[data-text-key="x"]').value=defaults.x;
        row.querySelector('input[data-text-key="y"]').value=defaults.y;
        row.querySelector('input[data-text-key="size"]').value=defaults.size;
        row.querySelector('[data-text-val="x"]').textContent=defaults.x;
        row.querySelector('[data-text-val="y"]').textContent=defaults.y;
        row.querySelector('[data-text-val="size"]').textContent=`${defaults.size}px`;
        safeRenderPortrait();
      });
    }

    box.appendChild(row);
  });
}

function drawText(text,x,y,size,weight=400,align="center",color=state.textColor,font=state.font){
  ctx.fillStyle=color;
  ctx.textAlign=align;
  ctx.textBaseline="alphabetic";
  ctx.font=`${weight} ${size}px "${font}"`;
  ctx.fillText(text,x,y);
}

function drawPlaneSilhouette(x,y,w,p,color,technical=false){
  ctx.save();
  ctx.translate(x,y);
  const s=w/500;
  ctx.scale(s,s);
  ctx.strokeStyle=color; ctx.fillStyle=color; ctx.lineWidth=technical?4:2;

  const family=(p?.family || "generic").toLowerCase();
  const poly=(pts)=>{
    ctx.beginPath();
    ctx.moveTo(pts[0][0],pts[0][1]);
    for(let i=1;i<pts.length;i++) ctx.lineTo(pts[i][0],pts[i][1]);
    ctx.closePath();
    technical ? ctx.stroke() : ctx.fill();
  };

  if(family==="helicopter"){
    ctx.beginPath();ctx.ellipse(245,120,95,48,0,0,Math.PI*2);technical?ctx.stroke():ctx.fill();
    poly([[35,115],[165,105],[165,130],[35,130],[12,145],[12,96]]);
    ctx.fillRect(235,25,10,55);ctx.fillRect(105,20,280,8);
  }else if(family==="ga"){
    poly([[15,120],[120,102],[210,98],[272,35],[310,35],[286,98],[410,105],[478,120],[408,135],[286,140],[310,205],[272,205],[210,140],[110,138]]);
  }else if(family==="atr"){
    poly([[10,120],[125,101],[212,96],[266,42],[298,42],[282,96],[410,105],[480,120],[410,136],[282,142],[298,198],[266,198],[212,142],[115,139]]);
    ctx.beginPath();ctx.arc(190,111,27,0,Math.PI*2);technical?ctx.stroke():ctx.fill();
    ctx.beginPath();ctx.arc(338,112,27,0,Math.PI*2);technical?ctx.stroke():ctx.fill();
  }else if(family==="a380" || family==="b747"){
    poly([[8,120],[105,98],[205,94],[270,20],[312,20],[287,94],[402,102],[486,120],[402,140],[287,146],[315,220],[270,220],[205,146],[95,142]]);
    if(!technical) ctx.fillRect(65,105,350,30);
  }else if(["a330","a350","b767","b777","b787"].includes(family)){
    poly([[8,120],[120,98],[208,92],[278,15],[320,15],[290,92],[414,103],[490,120],[414,139],[290,146],[322,225],[276,225],[208,146],[108,141]]);
  }else if(["ejet","crj"].includes(family)){
    poly([[12,120],[135,102],[218,98],[270,48],[304,48],[287,98],[410,106],[480,120],[410,135],[287,140],[305,194],[270,194],[218,140],[125,138]]);
  }else{
    poly([[10,120],[130,101],[218,96],[272,36],[310,36],[287,96],[414,105],[486,120],[414,137],[287,142],[312,205],[270,205],[218,142],[118,139]]);
  }

  if(technical){
    ctx.setLineDash([10,8]);
    ctx.beginPath();ctx.moveTo(30,120);ctx.lineTo(465,120);ctx.stroke();
    ctx.setLineDash([]);
  }
  ctx.restore();
}

function backgroundForStyle(){
  if(state.style==="blueprint") return "#23486a";
  if(state.style==="handdrawn" || state.style==="exploded" || state.style==="cutaway") return "#eee7d8";
  return state.bgColor;
}
function colorForStyle(){
  if(state.style==="blueprint") return "#e8f0f4";
  if(state.style==="handdrawn" || state.style==="exploded" || state.style==="cutaway") return "#272522";
  return state.textColor;
}

async function renderPortrait(){
  const bg=state.bgColor;
  const fg=state.textColor;

  ctx.fillStyle=bg;
  ctx.fillRect(0,0,1200,1600);

  ctx.strokeStyle=fg;
  ctx.globalAlpha=.62;
  ctx.lineWidth=3;
  ctx.strokeRect(46,46,1108,1508);
  ctx.globalAlpha=1;

  if(state.texts.eyebrow.visible) drawText(state.texts.eyebrow.value,88,105,26,700,"left",fg);
  if(state.texts.date.visible) drawText(state.texts.date.value,1112,105,22,600,"right",fg);

  const planesToDraw=state.selected.map(id=>planes.find(p=>p.id===id)).filter(Boolean);
  const count=planesToDraw.length;

  const startY=count<=1 ? 360 : count===2 ? 300 : count===3 ? 235 : 205;
  let yCursor=startY;

  for(let i=0;i<count;i++){
    const p=planesToDraw[i];
    const layout=getPlaneLayout(p.id,i,count);
    const y=yCursor + (layout.y || 0);

    const offsetX=(state.artOffsetX || 0) + (layout.x || 0);
    const offsetY=state.artOffsetY || 0;
    const scale=(state.artScale || 1) * (layout.scale || 1);

    let bounds=await drawVintageProfile(
      p,
      600+offsetX,
      y+offsetY,
      820*scale,
      200*scale
    );

    if(!bounds){
      const fallbackCx=600+offsetX;
      const fallbackCy=y+offsetY;
      const fallbackW=540*scale;
      const fallbackH=116*scale;
      bounds={
        left:fallbackCx-fallbackW/2, top:fallbackCy-fallbackH/2,
        right:fallbackCx+fallbackW/2, bottom:fallbackCy+fallbackH/2,
        width:fallbackW, height:fallbackH, cx:fallbackCx, cy:fallbackCy
      };
      ctx.strokeStyle=fg;
      ctx.globalAlpha=.38;
      ctx.lineWidth=2;
      ctx.strokeRect(bounds.left,bounds.top,bounds.width,bounds.height);
      ctx.globalAlpha=1;
      drawText("BILD NOCH NICHT IN DER BIBLIOTHEK",bounds.cx,bounds.cy-4,17,700,"center",fg);
      drawText(`${p.airline || "Unbekannte Airline"} · ${p.icaoType || p.type || "Typ unbekannt"}`,bounds.cx,bounds.cy+27,15,500,"center",fg);
    }

    drawPlaneInfo(p,bounds,layout,fg);
    yCursor += (layout.gap || 225);
  }

  const footerY=1240;
  const titleText=state.texts.title;
  const locationText=state.texts.location;
  const coordsText=state.texts.coords;

  if(titleText.visible) drawText(
    titleText.value,
    600+(titleText.x || 0),
    footerY+(titleText.y || 0),
    titleText.size || 38,
    600,"center",fg
  );

  if(locationText.visible) drawText(
    locationText.value,
    600+(locationText.x || 0),
    footerY+78+(locationText.y || 0),
    locationText.size || 58,
    700,"center",fg
  );

  if(coordsText.visible) drawText(
    coordsText.value,
    600+(coordsText.x || 0),
    footerY+130+(coordsText.y || 0),
    coordsText.size || 24,
    500,"center",fg
  );

  if(state.texts.quote.visible){
    const q=state.texts.quote.value;
    const words=q.split(" "); let line="", lines=[];
    words.forEach(word=>{
      const test=line+word+" ";
      ctx.font=`500 22px "${state.font}"`;
      if(ctx.measureText(test).width>760 && line){
        lines.push(line.trim());
        line=word+" ";
      }else{
        line=test;
      }
    });
    if(line) lines.push(line.trim());
    lines.slice(0,3).forEach((l,i)=>drawText(l,600,1450+i*30,22,500,"center",fg));
  }

  if(state.texts.author.visible){
    drawText("– "+state.texts.author.value+" –",600,1540,18,600,"center",fg);
  }

  applyVintagePrintEffect();
}

function applyVintagePrintEffect(){
  const strength=Math.max(0,Math.min(1,state.ditherStrength || 0));
  if(state.ditherMode==="flat" || strength<=0) return;

  const image=ctx.getImageData(0,0,1200,1600);
  const d=image.data;

  // Subtle poster-print texture. We keep it intentionally mild because the
  // final E-Ink conversion will quantize the palette again.
  const bayer=[
    [0,8,2,10],
    [12,4,14,6],
    [3,11,1,9],
    [15,7,13,5]
  ];

  for(let y=0;y<1600;y++){
    for(let x=0;x<1200;x++){
      const idx=(y*1200+x)*4;

      let delta=0;
      if(state.ditherMode==="bayer"){
        const v=bayer[y%4][x%4]/15 - .5;
        delta=v*18*strength;
      }else{
        // Deterministic pseudo-blue-noise-ish grain; stable across redraws.
        const n=Math.sin(x*12.9898+y*78.233)*43758.5453;
        const frac=n-Math.floor(n);
        delta=(frac-.5)*15*strength;
      }

      d[idx]=Math.max(0,Math.min(255,d[idx]+delta));
      d[idx+1]=Math.max(0,Math.min(255,d[idx+1]+delta));
      d[idx+2]=Math.max(0,Math.min(255,d[idx+2]+delta));
    }
  }
  ctx.putImageData(image,0,0);
}

document.getElementById("bgColor").addEventListener("input",e=>{state.bgColor=e.target.value;safeRenderPortrait();});
document.getElementById("textColor").addEventListener("input",e=>{state.textColor=e.target.value;safeRenderPortrait();});
document.getElementById("fontSelect").addEventListener("change",e=>{state.font=e.target.value;safeRenderPortrait();});

function renderLibraryStatus(assets){
  const el=document.getElementById("libraryTypeStatus");
  if(!el) return;
  const groups=[
    ["Airbus",["A20N","A21N","A318","A319","A320","A321","A332","A333","A339","A343","A346","A359","A35K","A388"]],
    ["Boeing",["B38M","B39M","B737","B738","B739","B744","B752","B763","B772","B77W","B788","B789"]],
    ["Regional",["CRJ9","DHC8","E190","E195"]]
  ];
  el.innerHTML=groups.map(([name,types])=>{
    const chips=types.map(t=>`<span class="type-status ${assets[t]?"ok":"missing"}">${t} ${assets[t]?"✓":"×"}</span>`).join("");
    return `<div class="type-status-group"><strong>${name}</strong><div>${chips}</div></div>`;
  }).join("");
}

async function refreshLibraryStatus(){
  try{
    const r=await fetch("/api/library/status");
    if(!r.ok) return;
    const data=await r.json();
    renderLibraryStatus(data.assets||{});
    const status=document.getElementById("libraryBuildStatus");
    if(status && data.available_count){
      status.className="panel-export-status ok";
      status.textContent=`Bibliothek: ${data.available_count}/${data.total_count} Kern-Typen vorhanden.`;
    }
  }catch(err){}
}
document.getElementById("artScale")?.addEventListener("input",e=>{state.artScale=Number(e.target.value)/100;safeRenderPortrait();});
document.getElementById("artOffsetX")?.addEventListener("input",e=>{state.artOffsetX=Number(e.target.value);safeRenderPortrait();});
document.getElementById("artOffsetY")?.addEventListener("input",e=>{state.artOffsetY=Number(e.target.value);safeRenderPortrait();});
document.getElementById("ditherMode")?.addEventListener("change",e=>{state.ditherMode=e.target.value;safeRenderPortrait();});
document.getElementById("ditherStrength")?.addEventListener("input",e=>{state.ditherStrength=Number(e.target.value)/100;safeRenderPortrait();});
document.getElementById("showAirlineOnAircraft")?.addEventListener("change",e=>{
  state.showAirlineOnAircraft=!!e.target.checked;
  safeRenderPortrait();
});
document.getElementById("refreshLiveBtn").addEventListener("click", async (event) => {
  event.preventDefault();
  event.stopPropagation();

  const button = document.getElementById("refreshLiveBtn");
  const oldText = button.textContent;

  try {
    button.disabled = true;
    button.textContent = "Lade Live-Flugzeuge …";
    await loadLiveAircraft();
    await refreshMissingBases();
  } finally {
    button.disabled = false;
    button.textContent = oldText;
  }
});



// V22.2 — observed missing base tracker and authenticated patch upload.
function formatSeenTimestamp(ts){
  if(!ts) return "–";
  try{return new Date(ts*1000).toLocaleString("de-DE");}catch(_){return "–";}
}

function patchToken(){
  return (document.getElementById("patchToken")?.value || "").trim();
}

async function patchMissingBase(type,file,row){
  const token=patchToken();
  if(!token){
    alert("Bitte zuerst den Patch-Token aus runtime/patch_token.txt eintragen.");
    return;
  }
  if(!file){
    alert(`Bitte eine PNG-Datei für ${type} auswählen.`);
    return;
  }
  if(file.type && file.type!=="image/png"){
    alert("Bitte ausschließlich PNG-Dateien verwenden.");
    return;
  }
  const status=row?.querySelector(".patch-result");
  if(status){status.textContent="Patch wird hochgeladen …";status.className="patch-result";}
  try{
    const raw=await file.arrayBuffer();
    const r=await fetch(`/api/library/patch?type=${encodeURIComponent(type)}`,{
      method:"POST",
      headers:{"Content-Type":"image/png","X-Aerofolio-Patch-Token":token},
      body:raw
    });
    const data=await r.json().catch(()=>({}));
    if(!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
    if(status){status.textContent=`✓ ${type} installiert`;status.className="patch-result patch-ok";}
    await refreshLibraryStatus();
    await refreshMissingBases();
    safeRenderPortrait();
  }catch(err){
    if(status){status.textContent=`✕ ${err.message}`;status.className="patch-result patch-error";}
  }
}

function renderMissingBases(rows){
  const el=document.getElementById("missingBaseList");
  if(!el) return;
  if(!rows?.length){
    el.innerHTML='<span class="muted">Aktuell keine fehlenden Live-Typen.</span>';
    return;
  }
  el.innerHTML=rows.map((m,i)=>{
    const ex=(m.examples||[])[(m.examples||[]).length-1]||{};
    const fallback=m.fallback?` · Fallback: ${m.fallback}`:"";
    const example=[ex.callsign,ex.registration,ex.operator].filter(Boolean).join(" · ");
    return `<div class="missing-base-row" data-missing-type="${m.type}">
      <div class="missing-base-row-top"><span class="missing-base-code">${m.type}</span><span class="muted">${m.seen_count||1}× gesehen</span></div>
      <div class="missing-base-meta">Zuletzt: ${formatSeenTimestamp(m.last_seen)}${fallback}${example?`<br>${example}`:""}</div>
      <div class="missing-base-actions"><input class="missing-file" type="file" accept="image/png"><button class="ghost mini patch-base-btn" type="button">PNG patchen</button></div>
      <div class="patch-result missing-base-meta"></div>
    </div>`;
  }).join("");
  el.querySelectorAll(".patch-base-btn").forEach(btn=>{
    btn.addEventListener("click",()=>{
      const row=btn.closest(".missing-base-row");
      const type=row.dataset.missingType;
      const file=row.querySelector(".missing-file")?.files?.[0];
      patchMissingBase(type,file,row);
    });
  });
}

async function refreshMissingBases(){
  try{
    const r=await fetch("/api/library/missing",{cache:"no-store"});
    if(!r.ok) return;
    const data=await r.json();
    renderMissingBases(data.missing||[]);
  }catch(_){ }
}

document.getElementById("patchToken")?.addEventListener("change",e=>{
  localStorage.setItem("aerofolioPatchToken",e.target.value||"");
});
const savedPatchToken=localStorage.getItem("aerofolioPatchToken");
if(savedPatchToken && document.getElementById("patchToken")) document.getElementById("patchToken").value=savedPatchToken;
document.getElementById("refreshMissingBases")?.addEventListener("click",refreshMissingBases);

renderPlaneList();
renderStyles();
renderTextControls();
updateQueryCoordinates();
safeRenderPortrait();

refreshLibraryStatus();
refreshMissingBases();



const AEROFOLIO_INSTALLED_VERSION = "23.1.0";

function compareVersions(a, b){
  const pa = String(a || "0").split(".").map(n => parseInt(n,10) || 0);
  const pb = String(b || "0").split(".").map(n => parseInt(n,10) || 0);
  const len = Math.max(pa.length, pb.length);
  for(let i=0;i<len;i++){
    const av = pa[i] || 0, bv = pb[i] || 0;
    if(av > bv) return 1;
    if(av < bv) return -1;
  }
  return 0;
}

async function checkForAerofolioUpdates(){
  const status = document.getElementById("updateStatus");
  const remote = document.getElementById("remoteVersion");
  const installed = document.getElementById("installedVersion");
  const btn = document.getElementById("checkUpdatesBtn");
  if(installed) installed.textContent = AEROFOLIO_INSTALLED_VERSION;
  if(status) status.textContent = "Prüfe GitHub…";
  if(btn) btn.disabled = true;
  try{
    const response = await fetch("/api/update/check", {cache:"no-store"});
    const data = await response.json();
    if(!response.ok || data.error) throw new Error(data.error || `HTTP ${response.status}`);
    const latest = data.latest || "–";
    if(remote) remote.textContent = latest;
    const cmp = compareVersions(AEROFOLIO_INSTALLED_VERSION, latest);
    if(status){
      if(cmp < 0){
        status.textContent = `Update ${latest} verfügbar.`;
        status.dataset.state = "available";
      }else if(cmp === 0){
        status.textContent = "AEROFOLIO ist aktuell.";
        status.dataset.state = "current";
      }else{
        status.textContent = "Lokale Version ist neuer als der Stable-Kanal.";
        status.dataset.state = "ahead";
      }
    }
  }catch(err){
    console.error("AEROFOLIO update check failed:", err);
    if(status){
      status.textContent = `Update-Prüfung fehlgeschlagen: ${err.message}`;
      status.dataset.state = "error";
    }
  }finally{
    if(btn) btn.disabled = false;
  }
}

window.addEventListener("DOMContentLoaded", ()=>{
  const btn = document.getElementById("checkUpdatesBtn");
  if(btn) btn.addEventListener("click", checkForAerofolioUpdates);
  const installed = document.getElementById("installedVersion");
  if(installed) installed.textContent = AEROFOLIO_INSTALLED_VERSION;
});

