AEROFOLIO V23.1 – Combined Patch

Enthält BEIDES:
1. Sticky Poster: Poster bleibt beim Herunterscrollen sichtbar.
2. Separate Steuerung für DER HIMMEL ÜBER, Standort und Koordinaten.

Installation:
- app.js, index.html und styles.css in den aktuellen AEROFOLIO-Hauptordner kopieren.
- Vorhandene Dateien ersetzen.
- start.bat neu starten.
- Browser Strg+F5.

Dieser Patch ersetzt die beiden vorherigen Einzelpatches.
