# AEROFOLIO 0.23.2.3

Entwicklungsstand vor 1.0.

## Update-Härtung
- neue 0.x-Versionslogik
- Migration von alten 23.2.x-Versionen
- Cache-Busting für app.js und styles.css
- automatischer Server-Neustart nach Systemupdate
- persistenter Update-Status statt Test-Badge
- SHA-256-Prüfung bleibt aktiv
- Update-Downloads nur von `raw.githubusercontent.com/Collex490/aerofolio`
- Downgrades werden serverseitig abgewiesen
- `data/`, `runtime/` und `assets/` bleiben bei Systemupdates erhalten
- Backup und Rollback bleiben aktiv

## Einmaliger Bridge-Hinweis
Die aktuell laufende 23.2.2 kennt die neue 0.x-Semantik noch nicht.
Deshalb wird dieses Paket für den einmaligen Remote-Übergang mit Manifest-Version
`23.2.3` veröffentlicht. Nach Installation migriert AEROFOLIO automatisch auf
`0.23.2.3`. Alle folgenden Releases verwenden direkt 0.x.
