# AEROFOLIO V23.1

Neu:
- GitHub-Updateprüfung über `Collex490/aerofolio`
- Button „Nach Updates suchen“
- Anzeige installierte Version / GitHub-Version
- Versionsvergleich im Browser
- GitHub-Zugriff läuft über den lokalen Python-Server (`/api/update/check`)

Noch nicht enthalten:
- automatischer Download
- Installation
- Backup/Rollback

Damit testen wir zuerst sicher nur die Erkennung einer neuen Version.
