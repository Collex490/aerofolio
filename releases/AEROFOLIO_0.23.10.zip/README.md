# AEROFOLIO V22

Eigenständige lokale Poster-Web-App für persönliche Flugzeug-Portraits.

## Datenquelle
- Live-Positionen: ADSB.lol
- Keine zweite proprietäre Datenquelle oder fremde Artwork-Bibliothek.

## Artwork
32 eigene Vintage-Base-PNGs liegen unter `assets/aircraft/base/`.
`data/aircraft_mapping.json` enthält die kanonischen Typen und Fallback-Aliase.

## Start
`start.bat` ausführen und anschließend die lokale Web-Oberfläche öffnen.

## Lizenzhinweis
Vor kommerziellem Vertrieb müssen die Nutzungsbedingungen aller externen Datenquellen und später verwendeter Airline-Marken/Liveries separat geprüft werden.


## V22.1 – angepinnte Flugzeug-Infos

Die Info-Texte werden jetzt relativ zur tatsächlich gerenderten Flugzeuggrafik verankert. Beim Verschieben oder Skalieren wandert der Text automatisch mit. Pro Flugzeug gibt es zusätzlich Text-Abstand sowie X/Y-Feinjustierung.


## V22.2 – fehlende Flugzeug-Bases & Fern-Patches

AEROFOLIO protokolliert bei jeder ADSB.lol-Abfrage exakte ICAO-Flugzeugtypen, für die noch keine eigene Base-PNG existiert. Die Liste erscheint im Einstellbereich unter **Fehlende Live-Bases** und wird in `data/missing_aircraft.json` gespeichert.

Eine fehlende Base kann direkt über die Oberfläche gepatcht werden. Beim ersten Serverstart wird dafür ein zufälliger Administrations-Token in `runtime/patch_token.txt` erzeugt. Diesen Token in der Oberfläche eintragen, eine PNG auswählen und **PNG patchen** drücken. Der Token wird nicht dauerhaft im Browser gespeichert. Der Server akzeptiert nur ICAO-artige Typcodes und valide PNG-Dateien und schreibt ausschließlich nach `assets/aircraft/base/<TYPE>_base.png`. Die Zuordnung in `data/aircraft_mapping.json` wird automatisch aktualisiert.

Der Administrations-Token schützt alle schreibenden API-Endpunkte, darunter Base-Installation, Panel-Konvertierung und Programmupdates. Direkt öffentlich ausgeliefert werden nur `index.html`, `app.js` und `styles.css`; insbesondere `runtime/`, `data/`, Backups und Quellcode sind über HTTP gesperrt.

Für Zugriff über LAN/VPN/Reverse-Proxy kann `AEROFOLIO_HOST=0.0.0.0` gesetzt werden. Numerische private IP-Adressen sind erlaubt. Zusätzliche lokale Hostnamen müssen kommasepariert über `AEROFOLIO_ALLOWED_HOSTS` freigegeben werden. Für einen festen Administrations-Token kann weiterhin `AEROFOLIO_PATCH_TOKEN` als Umgebungsvariable gesetzt werden. Administrative Endpunkte niemals ungeschützt ins öffentliche Internet stellen.
