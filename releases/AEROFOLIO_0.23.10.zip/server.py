#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import ipaddress
import subprocess
import sys
import json
import re
import math
import os
import sys
import time
import secrets
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

from engines.panel_codec import RGBA_BYTES, PANEL_BYTES, rgba_to_panel_bin, sha256_hex
import zipfile
import tempfile
import shutil
import threading

ROOT = Path(__file__).resolve().parent
HOST = os.environ.get("AEROFOLIO_HOST", "127.0.0.1")
PORT = int(os.environ.get("AEROFOLIO_PORT", "8000"))

ADSB_BASE = "https://api.adsb.lol"
USER_AGENT = "AEROFOLIO/0.23.2.9"
RUNTIME_DIR = ROOT / "runtime"
RUNTIME_DIR.mkdir(exist_ok=True)
CURRENT_PANEL = RUNTIME_DIR / "current_panel.bin"
MISSING_AIRCRAFT = ROOT / "data" / "missing_aircraft.json"
PATCH_TOKEN_FILE = RUNTIME_DIR / "patch_token.txt"
PUBLIC_FILES = frozenset({"index.html", "app.js", "styles.css"})
ADMIN_HEADER_NAMES = ("X-Aerofolio-Admin-Token", "X-Aerofolio-Patch-Token")
ASSET_MANIFEST_URL = "https://raw.githubusercontent.com/Collex490/aerofolio/main/assets/manifest.json"
MAX_JSON_RESPONSE_BYTES = 5_000_000
MAX_REMOTE_ASSET_BYTES = 16_000_000
_AIRCRAFT_MAPPING_LOCK = threading.RLock()
_MISSING_AIRCRAFT_LOCK = threading.RLock()


def _atomic_write_text(path, text):
    """Write a text file atomically without sharing a fixed temporary filename."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
            temp_path = Path(handle.name)
        os.replace(temp_path, path)
        temp_path = None
    finally:
        if temp_path is not None:
            try:
                temp_path.unlink()
            except FileNotFoundError:
                pass


def _atomic_write_bytes(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
            temp_path = Path(handle.name)
        os.replace(temp_path, path)
        temp_path = None
    finally:
        if temp_path is not None:
            try:
                temp_path.unlink()
            except FileNotFoundError:
                pass


def _json_text(data):
    return json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n"

def ensure_pillow():
    """Ensure Pillow is importable by a fresh Python process."""
    check = subprocess.run(
        [sys.executable, "-c", "from PIL import Image; print(Image.__version__)"],
        cwd=str(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    if check.returncode == 0:
        return True, check.stdout.strip()

    install = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--user", "Pillow"],
        cwd=str(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )
    if install.returncode != 0:
        return False, install.stdout[-3000:]

    verify = subprocess.run(
        [sys.executable, "-c", "from PIL import Image; print(Image.__version__)"],
        cwd=str(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    if verify.returncode != 0:
        return False, (verify.stdout + "\n" + verify.stderr)[-3000:]
    return True, verify.stdout.strip()

def load_aircraft_mapping():
    path = ROOT / "data" / "aircraft_mapping.json"
    with _AIRCRAFT_MAPPING_LOCK:
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {"assets": {}, "aliases": {}}

def library_status():
    """Return availability for the 30 canonical AEROFOLIO base illustrations."""
    mapping = load_aircraft_mapping()
    result = {}
    for code, rel in mapping.get("assets", {}).items():
        result[code] = (ROOT / rel).is_file()
    return result


def save_aircraft_mapping(mapping):
    path = ROOT / "data" / "aircraft_mapping.json"
    with _AIRCRAFT_MAPPING_LOCK:
        _atomic_write_text(path, _json_text(mapping))

def load_missing_aircraft():
    with _MISSING_AIRCRAFT_LOCK:
        try:
            data = json.loads(MISSING_AIRCRAFT.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

def save_missing_aircraft(data):
    with _MISSING_AIRCRAFT_LOCK:
        _atomic_write_text(MISSING_AIRCRAFT, _json_text(data))

def get_patch_token():
    env = (os.environ.get("AEROFOLIO_PATCH_TOKEN") or "").strip()
    if env:
        return env
    if PATCH_TOKEN_FILE.exists():
        token = PATCH_TOKEN_FILE.read_text(encoding="utf-8").strip()
        if token:
            return token
    token = secrets.token_urlsafe(24)
    PATCH_TOKEN_FILE.write_text(token + "\n", encoding="utf-8")
    return token

def admin_authorized(handler):
    supplied = ""
    for header_name in ADMIN_HEADER_NAMES:
        supplied = (handler.headers.get(header_name) or "").strip()
        if supplied:
            break
    return secrets.compare_digest(supplied, get_patch_token())


def _request_hostname(host_header):
    try:
        return (urllib.parse.urlsplit("//" + str(host_header or "")).hostname or "").lower()
    except ValueError:
        return ""


def host_allowed(host_header):
    """Reject DNS-rebinding hostnames while retaining localhost and numeric LAN access."""
    hostname = _request_hostname(host_header)
    if not hostname:
        return False

    configured = {
        item.strip().lower().rstrip(".")
        for item in os.environ.get("AEROFOLIO_ALLOWED_HOSTS", "").split(",")
        if item.strip()
    }
    configured.update({"localhost", "127.0.0.1", "::1"})
    if HOST not in ("0.0.0.0", "::", ""):
        configured.add(HOST.lower().rstrip("."))
    if hostname.rstrip(".") in configured:
        return True

    try:
        address = ipaddress.ip_address(hostname)
        return address.is_loopback or address.is_private or address.is_link_local
    except ValueError:
        return False


def origin_allowed(origin_header, host_header):
    """Allow non-browser clients without Origin and same-origin browser requests."""
    origin = str(origin_header or "").strip()
    if not origin:
        return True
    try:
        parsed = urllib.parse.urlsplit(origin)
    except ValueError:
        return False
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return False
    return parsed.netloc.lower() == str(host_header or "").strip().lower()


def public_path_for_request(url_path):
    """Return a public file path or None; never expose project/runtime internals."""
    try:
        decoded = urllib.parse.unquote(urllib.parse.urlparse(url_path).path)
    except Exception:
        return None
    if decoded in ("", "/"):
        decoded = "/index.html"
    if "\x00" in decoded or "\\" in decoded or ":" in decoded:
        return None
    parts = [part for part in decoded.split("/") if part]
    if len(parts) != 1 or parts[0] in (".", "..") or parts[0] not in PUBLIC_FILES:
        return None
    candidate = (ROOT / parts[0]).resolve()
    try:
        candidate.relative_to(ROOT.resolve())
    except ValueError:
        return None
    return candidate

def sanitize_designator(value):
    code = clean_aircraft_designator(value)
    if not code or not re.fullmatch(r"[A-Z0-9]{2,6}", code):
        return ""
    return code

def exact_base_available(code):
    mapping = load_aircraft_mapping()
    rel = mapping.get("assets", {}).get(code)
    return bool(rel and (ROOT / rel).is_file())

def record_missing_aircraft(aircraft):
    """Persist exact live aircraft types for which no dedicated base exists."""
    if not aircraft:
        return
    mapping = load_aircraft_mapping()
    assets = mapping.get("assets", {})
    aliases = mapping.get("aliases", {})
    with _MISSING_AIRCRAFT_LOCK:
        missing = load_missing_aircraft()
        now = int(time.time())
        changed = False
        for ac in aircraft:
            code = sanitize_designator(ac.get("type", ""))
            if not code or code in assets:
                continue
            entry = missing.get(code, {})
            entry["type"] = code
            entry["first_seen"] = entry.get("first_seen", now)
            entry["last_seen"] = now
            entry["seen_count"] = int(entry.get("seen_count", 0)) + 1
            fallback = aliases.get(code)
            entry["fallback"] = fallback if fallback and fallback != code else None
            examples = entry.get("examples", [])
            example = {
                "callsign": ac.get("callsign") or "",
                "registration": ac.get("registration") or "",
                "operator": ac.get("operator") or "",
            }
            if any(example.values()) and example not in examples:
                examples.append(example)
                examples = examples[-5:]
            entry["examples"] = examples
            missing[code] = entry
            changed = True
        if changed:
            save_missing_aircraft(missing)

def missing_aircraft_status():
    mapping = load_aircraft_mapping()
    assets = mapping.get("assets", {})
    missing = load_missing_aircraft()
    rows = []
    for code, entry in missing.items():
        if code in assets and exact_base_available(code):
            continue
        row = dict(entry)
        row["type"] = code
        rows.append(row)
    rows.sort(key=lambda x: (-int(x.get("last_seen", 0)), x.get("type", "")))
    return rows

def _read_limited_response(response, max_bytes):
    declared = response.headers.get("Content-Length")
    if declared:
        try:
            declared_size = int(declared)
        except (TypeError, ValueError):
            declared_size = None
        if declared_size is not None and (declared_size < 0 or declared_size > max_bytes):
            raise ValueError("Remote-Antwort ist zu groß")
    data = response.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise ValueError("Remote-Antwort ist zu groß")
    return data


def fetch_json(url: str, timeout: float = 12.0, max_bytes: int = MAX_JSON_RESPONSE_BYTES):
    req = urllib.request.Request(
        url,
        headers={
            "Accept": "application/json",
            "User-Agent": USER_AGENT,
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(_read_limited_response(r, max_bytes).decode("utf-8-sig"))


def fetch_bytes(url: str, timeout: float = 20.0, max_bytes: int = MAX_REMOTE_ASSET_BYTES):
    req = urllib.request.Request(
        url,
        headers={"Accept": "image/png", "User-Agent": USER_AGENT},
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return _read_limited_response(response, max_bytes)

def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dp = math.radians(lat2-lat1)
    dl = math.radians(lon2-lon1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*r*math.asin(math.sqrt(a))

def extract_aircraft(payload):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ("ac", "aircraft"):
            if isinstance(payload.get(key), list):
                return payload[key]
    return []

def first_nonempty(*vals):
    for v in vals:
        if v is None:
            continue
        if isinstance(v, str):
            v = v.strip()
            if v:
                return v
        else:
            return v
    return None


def finite_number(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


AIRLINE_PREFIXES = {
    "DLH":"Lufthansa","EWG":"Eurowings","RYR":"Ryanair","EZY":"easyJet",
    "SWR":"SWISS","AUA":"Austrian Airlines","KLM":"KLM","AFR":"Air France",
    "BAW":"British Airways","BEL":"Brussels Airlines","SAS":"SAS",
    "TAP":"TAP Air Portugal","IBE":"Iberia","VLG":"Vueling","ITY":"ITA Airways",
    "THY":"Turkish Airlines","QTR":"Qatar Airways","UAE":"Emirates",
    "ETD":"Etihad Airways","SIA":"Singapore Airlines","LOT":"LOT Polish Airlines",
    "CFG":"Condor","TUI":"TUI","WZZ":"Wizz Air","ACA":"Air Canada",
    "UAL":"United Airlines","AAL":"American Airlines","DAL":"Delta Air Lines",
    "FDX":"FedEx","UPS":"UPS Airlines"
}

def operator_from_callsign(callsign):
    if not callsign: return ""
    prefix="".join(ch for ch in callsign.upper() if ch.isalpha())[:3]
    return AIRLINE_PREFIXES.get(prefix,"")

def aircraft_family(type_code):
    t=(type_code or "").upper().strip()
    groups=[
      (("A318","A319","A320","A321","A20N","A21N"),"a320"),
      (("A332","A333","A338","A339"),"a330"),
      (("A359","A35K"),"a350"),(("A388",),"a380"),
      (("B737","B738","B739","B38M","B39M"),"b737"),
      (("B744","B748"),"b747"),(("B752","B753"),"b757"),
      (("B763","B764"),"b767"),(("B772","B773","B77L","B77W"),"b777"),
      (("B788","B789","B78X"),"b787"),
      (("E170","E175","E190","E195","E290","E295"),"ejet"),
      (("CRJ",),"crj"),(("AT43","AT45","AT46","AT72","AT75","AT76"),"atr"),
      (("C172","C182","C206","C208","C210","A210"),"ga")
    ]
    for prefixes,family in groups:
        if t.startswith(prefixes): return family
    if t.startswith(("EC","AS3","B06","R22","R44")): return "helicopter"
    return "generic"


def clean_aircraft_designator(*values):
    """Return a plausible ICAO aircraft designator from a code or descriptive name."""
    invalid = {
        "adsb_icao", "adsb_icao_nt", "adsr_icao", "tisb_icao",
        "mlat", "other", "mode_s", "mode_ac"
    }
    descriptive = {
        "AIRBUS A319":"A319",
        "AIRBUS A320":"A320",
        "AIRBUS A320-200":"A320",
        "AIRBUS A320NEO":"A20N",
        "AIRBUS A321":"A321",
        "AIRBUS A321NEO":"A21N",
        "AIRBUS A330-200":"A332",
        "AIRBUS A330-300":"A333",
        "AIRBUS A330-800":"A338",
        "AIRBUS A330-800NEO":"A338",
        "AIRBUS A330-900":"A339",
        "AIRBUS A330-900NEO":"A339",
        "AIRBUS A350-900":"A359",
        "AIRBUS A350-1000":"A35K",
        "AIRBUS A380-800":"A388",
        "BOEING 737-800":"B738",
        "BOEING 737 MAX 8":"B38M",
        "BOEING 747-400":"B744",
        "BOEING 747-8":"B748",
        "BOEING 747-8F":"B748",
        "BOEING 757-200":"B752",
        "BOEING 767-300":"B763",
        "BOEING 767-300F":"B763",
        "BOEING 777-200":"B772",
        "BOEING 777-200LR":"B77L",
        "BOEING 777-300ER":"B77W",
        "BOEING 787-8":"B788",
        "BOEING 787-9":"B789",
        "BOEING 787-10":"B78X",
        "EMBRAER E190":"E190",
        "EMBRAER E195":"E195",
        "CESSNA 172":"C172",
    }

    for value in values:
        if value is None:
            continue
        raw = str(value).strip()
        if not raw:
            continue

        if raw.lower() in invalid:
            continue

        upper = re.sub(r"\s+", " ", raw.upper()).strip()

        if 2 <= len(upper) <= 6 and upper.isalnum():
            return upper

        if upper in descriptive:
            return descriptive[upper]

        normalized = re.sub(r"[^A-Z0-9]+", "", upper)
        for label, code in descriptive.items():
            if normalized == re.sub(r"[^A-Z0-9]+", "", label):
                return code

    return ""

def normalize(raw, source, center_lat, center_lon):
    try:
        lat = float(raw.get("lat"))
        lon = float(raw.get("lon"))
    except (TypeError, ValueError):
        return None
    if not (math.isfinite(lat) and math.isfinite(lon)):
        return None
    if not (-90 <= lat <= 90 and -180 <= lon <= 180):
        return None

    callsign = first_nonempty(raw.get("flight"), raw.get("callsign"))
    if isinstance(callsign, str):
        callsign = "".join(callsign.split())

    hexid = first_nonempty(raw.get("hex"), raw.get("icao24"))
    if isinstance(hexid, str):
        hexid = hexid.lower().strip()

    registration = first_nonempty(raw.get("r"), raw.get("registration"), raw.get("reg"))
    aircraft_type = clean_aircraft_designator(raw.get("t"), raw.get("type_designator"), raw.get("type"))
    operator = first_nonempty(raw.get("ownOp"), raw.get("operator"), raw.get("airline"))
    if not operator:
        operator = operator_from_callsign(callsign)

    alt = first_nonempty(raw.get("alt_baro"), raw.get("alt_geom"), raw.get("altitude"))
    altitude_m = None
    if not (isinstance(alt, str) and alt.lower() == "ground"):
        altitude_ft = finite_number(alt)
        if altitude_ft is not None:
            altitude_m = altitude_ft * 0.3048

    return {
        "hex": hexid or "",
        "callsign": callsign or "",
        "registration": registration or "",
        "type": aircraft_type or "",
        "family": aircraft_family(aircraft_type),
        "operator": operator or "",
        "altitude_m": altitude_m,
        "lat": lat,
        "lon": lon,
        "distance_km": haversine_km(center_lat, center_lon, lat, lon),
        "track": finite_number(raw.get("track")),
        "ground_speed": finite_number(raw.get("gs")),
        "source": source,
        "sources": [source],
        "route": "",
    }

def provider_request(base, lat, lon, radius_nm, source):
    radius_nm = max(1, min(250, int(math.ceil(float(radius_nm)))))
    url = f"{base}/v2/point/{lat:.6f}/{lon:.6f}/{radius_nm}"
    started = time.time()
    try:
        payload = fetch_json(url)
        normalized = []
        for raw in extract_aircraft(payload):
            item = normalize(raw, source, lat, lon)
            if item:
                normalized.append(item)
        normalized.sort(key=lambda x: x["distance_km"])
        return {
            "ok": True,
            "count": len(normalized),
            "error": None,
            "elapsed_ms": round((time.time()-started)*1000),
            "aircraft": normalized,
        }
    except Exception as e:
        return {
            "ok": False,
            "count": 0,
            "error": f"{type(e).__name__}: {e}",
            "elapsed_ms": round((time.time()-started)*1000),
            "aircraft": [],
        }

def merge_aircraft(aircraft):
    aircraft = list(aircraft)
    aircraft.sort(key=lambda x: x.get("distance_km", 1e9))
    return aircraft[:40]

def resolve_local_asset(designator):
    mapping = load_aircraft_mapping()
    requested = (designator or "").upper().strip()
    dtype = mapping.get("aliases", {}).get(requested, requested)
    rel = mapping.get("assets", {}).get(dtype)
    if not rel:
        return None, None
    path = ROOT / rel
    if not path.is_file():
        return None, None
    return {"type": dtype, "path": rel, "style": "vintage", "view": "side"}, path


def _validated_remote_asset(item):
    if not isinstance(item, dict):
        raise ValueError("Ungültiger Asset-Eintrag")
    code = sanitize_designator(item.get("key"))
    if not code or code != str(item.get("key") or "").strip().upper():
        raise ValueError("Ungültiger Asset-Typcode")
    if item.get("type") != "aircraft":
        raise ValueError(f"Nicht unterstützter Asset-Typ für {code}")

    rel = str(item.get("path") or "").replace("\\", "/").strip("/")
    expected_rel = f"aircraft/base/{code}_base.png"
    if rel != expected_rel:
        raise ValueError(f"Ungültiger Asset-Pfad für {code}")

    url = str(item.get("url") or "").strip()
    parsed = urllib.parse.urlsplit(url)
    expected_path = f"/Collex490/aerofolio/main/assets/{expected_rel}"
    if (
        parsed.scheme != "https"
        or parsed.netloc != "raw.githubusercontent.com"
        or parsed.path != expected_path
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError(f"Nicht freigegebene Asset-URL für {code}")

    digest = str(item.get("sha256") or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ValueError(f"Ungültige SHA-256-Prüfsumme für {code}")
    return {
        "key": code,
        "type": "aircraft",
        "path": expected_rel,
        "url": url,
        "sha256": digest,
    }


def fetch_remote_asset_manifest():
    manifest = fetch_json(ASSET_MANIFEST_URL, timeout=8.0, max_bytes=1_000_000)
    if not isinstance(manifest, dict):
        raise ValueError("Ungültiges Remote-Asset-Manifest")
    if manifest.get("version") == 1 and isinstance(manifest.get("assets"), list):
        return manifest
    # Compatibility with the initially published, empty three-list manifest.
    if manifest.get("version") is None and isinstance(manifest.get("aircraft_bases"), list):
        return {"version": 1, "assets": manifest["aircraft_bases"]}
    raise ValueError("Remote-Asset-Manifest enthält keine unterstützte Asset-Liste")


def remote_asset_index(manifest):
    if not isinstance(manifest, dict) or not isinstance(manifest.get("assets"), list):
        raise ValueError("Ungültiges Remote-Asset-Manifest")
    result = {}
    for raw_item in manifest["assets"]:
        item = _validated_remote_asset(raw_item)
        code = item["key"]
        if code in result:
            raise ValueError(f"Doppelter Asset-Typcode: {code}")
        result[code] = item
    return result


def _validate_png_bytes(data):
    if len(data) < 24 or data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("Remote-Asset ist keine PNG-Datei")
    from PIL import Image
    import io
    with Image.open(io.BytesIO(data)) as image:
        if image.format != "PNG":
            raise ValueError("Remote-Asset ist keine PNG-Datei")
        width, height = image.size
        if width < 1 or height < 1 or width > 8192 or height > 8192:
            raise ValueError("Remote-PNG hat ungültige Abmessungen")
        image.verify()


def _remove_missing_aircraft(code):
    with _MISSING_AIRCRAFT_LOCK:
        missing = load_missing_aircraft()
        if code in missing:
            missing.pop(code, None)
            save_missing_aircraft(missing)


def install_remote_asset(item):
    item = _validated_remote_asset(item)
    raw = fetch_bytes(item["url"])
    actual = hashlib.sha256(raw).hexdigest().lower()
    if not secrets.compare_digest(actual, item["sha256"]):
        raise ValueError(f"SHA-256 stimmt für {item['key']} nicht")
    _validate_png_bytes(raw)

    code = item["key"]
    target = ROOT / "assets" / "aircraft" / "base" / f"{code}_base.png"
    _atomic_write_bytes(target, raw)
    with _AIRCRAFT_MAPPING_LOCK:
        mapping = load_aircraft_mapping()
        mapping.setdefault("assets", {})[code] = f"assets/aircraft/base/{code}_base.png"
        mapping.setdefault("aliases", {})[code] = code
        save_aircraft_mapping(mapping)
    _remove_missing_aircraft(code)
    return f"assets/aircraft/base/{code}_base.png"



UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/Collex490/aerofolio/main/latest.json"

def fetch_update_manifest():
    req = urllib.request.Request(
        UPDATE_MANIFEST_URL,
        headers={"User-Agent": "AEROFOLIO-Updater/0.23.2.9"}
    )
    with urllib.request.urlopen(req, timeout=8) as response:
        raw = response.read().decode("utf-8-sig")
    data = json.loads(raw)
    if data.get("product") != "AEROFOLIO":
        raise ValueError("Ungültiges Update-Manifest")
    return data



UPDATE_STATUS_FILE = RUNTIME_DIR / "last_update.json"

def normalize_version_parts(value):
    parts = []
    for token in str(value or "0").lstrip("vV").split("."):
        try:
            parts.append(int(token))
        except ValueError:
            parts.append(0)
    # Legacy migration: 23.2.x means 0.23.2.x
    if len(parts) == 3 and parts[0] >= 10:
        return [0] + parts
    return parts

def compare_versions(a, b):
    pa, pb = normalize_version_parts(a), normalize_version_parts(b)
    width = max(len(pa), len(pb))
    pa += [0] * (width - len(pa))
    pb += [0] * (width - len(pb))
    return (pa > pb) - (pa < pb)

def read_local_version():
    path = ROOT / "data" / "version.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        value = str(data.get("version") or "0")
        # One-time migration from legacy 23.2.x to 0.23.2.x
        parts = normalize_version_parts(value)
        if len(value.split(".")) == 3 and value.split(".")[0].isdigit() and int(value.split(".")[0]) >= 10:
            migrated = ".".join(str(x) for x in parts)
            data["version"] = migrated
            path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            return migrated
        return value
    except Exception:
        return "0"

def package_url_allowed(url):
    try:
        parsed = urllib.parse.urlparse(url)
    except Exception:
        return False
    if parsed.scheme != "https":
        return False
    if parsed.netloc != "raw.githubusercontent.com":
        return False
    return parsed.path.startswith("/Collex490/aerofolio/")

def write_update_status(payload):
    try:
        UPDATE_STATUS_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except Exception:
        pass

def _write_detached_update_helper(zip_path, version):
    helper = RUNTIME_DIR / "update_handoff.py"
    log_path = RUNTIME_DIR / "update_handoff.log"
    root_literal = repr(str(ROOT))
    python_literal = repr(sys.executable)
    zip_literal = repr(str(zip_path))
    version_literal = repr(str(version))
    port_literal = int(PORT)

    helper_code = f"""import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

ROOT = Path({root_literal})
PYTHON = {python_literal}
ZIP_PATH = Path({zip_literal})
VERSION = {version_literal}
PORT = {port_literal}
RUNTIME = ROOT / "runtime"
LOG = RUNTIME / "update_handoff.log"
STATUS = RUNTIME / "last_update.json"
PROTECTED = {{"runtime", "data", "assets"}}

def log(msg):
    try:
        RUNTIME.mkdir(parents=True, exist_ok=True)
        with LOG.open("a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " " + str(msg) + "\\n")
    except Exception:
        pass

def write_status(payload):
    try:
        STATUS.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except Exception:
        pass

def port_free():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.settimeout(0.25)
        return s.connect_ex(("127.0.0.1", PORT)) != 0
    finally:
        s.close()

def wait_port_free(seconds=25):
    end = time.time() + seconds
    while time.time() < end:
        if port_free():
            return True
        time.sleep(0.25)
    return False

def wait_port_open(seconds=30):
    end = time.time() + seconds
    while time.time() < end:
        if not port_free():
            return True
        time.sleep(0.35)
    return False

def safe_extract(zip_path, dest):
    dest_abs = os.path.abspath(dest)
    with zipfile.ZipFile(zip_path, "r") as z:
        for member in z.infolist():
            target = os.path.abspath(os.path.join(dest_abs, member.filename))
            if not (target == dest_abs or target.startswith(dest_abs + os.sep)):
                raise ValueError("Unsicherer ZIP-Pfad: " + member.filename)
        z.extractall(dest_abs)

def copy_payload(payload, backup):
    changed = []
    for name in os.listdir(payload):
        if name in PROTECTED or name == "__pycache__":
            continue
        src = os.path.join(payload, name)
        dst = os.path.join(ROOT, name)
        if os.path.exists(dst):
            shutil.move(dst, os.path.join(backup, name))
        if os.path.isdir(src):
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)
        changed.append(name)
    return changed

def set_version(version):
    vp = ROOT / "data" / "version.json"
    try:
        data = json.loads(vp.read_text(encoding="utf-8-sig"))
    except Exception:
        data = {{"product": "AEROFOLIO", "channel": "stable"}}
    data["version"] = version
    vp.write_text(json.dumps(data, indent=2), encoding="utf-8")

def restore_backup(changed, backup, old_version):
    for name in changed:
        dst = ROOT / name
        try:
            if dst.is_dir():
                shutil.rmtree(dst, ignore_errors=True)
            elif dst.exists():
                dst.unlink()
        except Exception:
            pass
    if backup.exists():
        for item in backup.iterdir():
            shutil.move(str(item), str(ROOT / item.name))
    set_version(old_version)

def launch_server():
    flags = 0
    if os.name == "nt":
        flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
    return subprocess.Popen(
        [PYTHON, "server.py"],
        cwd=str(ROOT),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=flags,
        close_fds=(os.name != "nt")
    )

def stop_process(proc):
    try:
        proc.terminate()
        proc.wait(timeout=4)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass

def main():
    log("handoff started for " + VERSION)

    if not wait_port_free():
        raise RuntimeError("Alter Server hat Port nicht freigegeben.")

    stage = Path(tempfile.mkdtemp(prefix="aerofolio-handoff-", dir=str(RUNTIME)))
    backup_root = RUNTIME / "backups"
    backup_root.mkdir(parents=True, exist_ok=True)
    backup = backup_root / (time.strftime("%Y%m%d-%H%M%S") + "-" + VERSION.replace("/", "_"))
    backup.mkdir(parents=True, exist_ok=True)

    old_version = "0"
    try:
        vp = ROOT / "data" / "version.json"
        if vp.exists():
            old_version = str(json.loads(vp.read_text(encoding="utf-8-sig")).get("version") or "0")
    except Exception:
        pass

    changed = []
    proc = None
    try:
        safe_extract(ZIP_PATH, stage)
        entries = list(stage.iterdir())
        payload = entries[0] if len(entries) == 1 and entries[0].is_dir() else stage

        changed = copy_payload(str(payload), str(backup))
        set_version(VERSION)

        write_status({{
            "ok": True,
            "phase": "files_installed",
            "version": VERSION,
            "previous_version": old_version,
            "backup": str(backup),
            "installed_at": time.time()
        }})

        proc = launch_server()
        log("new server spawned pid=" + str(proc.pid))

        if not wait_port_open():
            raise RuntimeError("Neuer Server wurde nicht erreichbar.")

        write_status({{
            "ok": True,
            "phase": "complete",
            "version": VERSION,
            "previous_version": old_version,
            "backup": str(backup),
            "installed_at": time.time()
        }})
        log("update complete " + VERSION)
        return 0

    except Exception as exc:
        log("update failed: " + repr(exc))
        if proc is not None:
            stop_process(proc)

        try:
            restore_backup(changed, backup, old_version)
            rollback_proc = launch_server()
            log("rollback server spawned pid=" + str(rollback_proc.pid))
            wait_port_open(20)
            write_status({{
                "ok": False,
                "phase": "rolled_back",
                "version": VERSION,
                "restored_version": old_version,
                "error": str(exc),
                "failed_at": time.time()
            }})
        except Exception as rollback_exc:
            log("rollback failed: " + repr(rollback_exc))
            write_status({{
                "ok": False,
                "phase": "rollback_failed",
                "version": VERSION,
                "restored_version": old_version,
                "error": str(exc),
                "rollback_error": str(rollback_exc),
                "failed_at": time.time()
            }})
        return 2

    finally:
        shutil.rmtree(stage, ignore_errors=True)

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        log("fatal helper error: " + repr(exc))
        write_status({{
            "ok": False,
            "phase": "helper_failed",
            "version": VERSION,
            "error": str(exc),
            "failed_at": time.time()
        }})
        sys.exit(3)
"""
    helper.write_text(helper_code, encoding="utf-8")
    return helper, log_path


def prepare_update_handoff(manifest):
    package_url = manifest.get("package_url")
    expected = str(manifest.get("sha256") or "").lower()
    version = str(manifest.get("latest") or "")

    if not package_url or not expected or not version:
        raise ValueError("Update-Manifest unvollständig")
    if not package_url_allowed(package_url):
        raise ValueError("Update-URL ist nicht freigegeben")

    local_version = read_local_version()
    if compare_versions(version, local_version) <= 0:
        raise ValueError(f"Kein neueres Update: lokal {local_version}, remote {version}")

    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    download_path = RUNTIME_DIR / f"update-{version}.zip"

    req = urllib.request.Request(
        package_url,
        headers={"User-Agent": "AEROFOLIO-Updater/0.23.2.9", "Cache-Control": "no-cache"}
    )
    with urllib.request.urlopen(req, timeout=60) as response, open(download_path, "wb") as f:
        shutil.copyfileobj(response, f)

    h = hashlib.sha256()
    with open(download_path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    actual = h.hexdigest().lower()

    if actual != expected:
        try:
            download_path.unlink()
        except Exception:
            pass
        raise ValueError(f"SHA-256 stimmt nicht: {actual}")

    helper, log_path = _write_detached_update_helper(download_path, version)

    write_update_status({
        "ok": True,
        "phase": "prepared",
        "version": version,
        "previous_version": local_version,
        "package": str(download_path),
        "prepared_at": time.time()
    })

    flags = 0
    if os.name == "nt":
        flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)

    subprocess.Popen(
        [sys.executable, str(helper)],
        cwd=str(ROOT),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=flags,
        close_fds=(os.name != "nt")
    )

    return {
        "ok": True,
        "version": version,
        "handoff_started": True,
        "restart_required": False,
        "message": "Update vorbereitet. Externer Helper übernimmt Installation und Neustart."
    }


def request_process_exit(delay=1.4):
    def _exit():
        try:
            server_obj = globals().get("server")
            if server_obj is not None:
                server_obj.server_close()
        except Exception:
            pass
        os._exit(0)
    threading.Timer(delay, _exit).start()

def _safe_extract_zip(zip_path, dest):
    dest = os.path.abspath(dest)
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.infolist():
            target = os.path.abspath(os.path.join(dest, member.filename))
            if not (target == dest or target.startswith(dest + os.sep)):
                raise ValueError("Unsicherer ZIP-Pfad erkannt")
        zf.extractall(dest)


class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        public_path = public_path_for_request(path)
        return str(public_path if public_path is not None else ROOT / ".aerofolio-denied")

    def request_host_allowed(self):
        return host_allowed(self.headers.get("Host"))

    def require_admin(self):
        if not self.request_host_allowed():
            self.send_json({"error": "Nicht erlaubter Host."}, 403)
            return False
        if not origin_allowed(self.headers.get("Origin"), self.headers.get("Host")):
            self.send_json({"error": "Fremder Ursprung ist nicht erlaubt."}, 403)
            return False
        if not admin_authorized(self):
            self.send_json({"error": "Administrations-Token fehlt oder ist falsch."}, 401)
            return False
        return True

    def log_message(self, fmt, *args):
        sys.stdout.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

    def send_json(self, obj, status=200):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def send_bytes(self, data, content_type, status=200, cache_seconds=86400, extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", f"public, max-age={cache_seconds}")
        if extra_headers:
            for key, value in extra_headers.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)

    def read_body(self, max_bytes=10_000_000):
        try:
            n = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("invalid Content-Length")
        if n < 0 or n > max_bytes:
            raise ValueError("request body too large")
        return self.rfile.read(n)

    def read_json_body(self, max_bytes=1_000_000):
        raw = self.read_body(max_bytes=max_bytes)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return None


    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/api/update/restart" and not self.require_admin():
            return

        if parsed.path == "/api/assets/install-missing":
            try:
                payload = self.read_json_body(max_bytes=100_000) or {}
                if not isinstance(payload, dict) or not isinstance(payload.get("codes", []), list):
                    return self.send_json({"ok": False, "error": "Ungültige Typcode-Liste."}, status=400)
                codes = []
                for value in payload.get("codes", []):
                    code = sanitize_designator(value)
                    if not code:
                        return self.send_json({"ok": False, "error": "Ungültiger Typcode."}, status=400)
                    if code not in codes:
                        codes.append(code)
                if len(codes) > 100:
                    return self.send_json({"ok": False, "error": "Zu viele Typcodes."}, status=400)
                manifest = fetch_remote_asset_manifest()
                index = remote_asset_index(manifest)
                installed, unavailable, errors = [], [], []
                for code in codes:
                    item = index.get(code)
                    if not item:
                        unavailable.append(code)
                        continue
                    try:
                        installed.append({"code": code, "path": install_remote_asset(item)})
                    except Exception as exc:
                        errors.append({"code": code, "error": str(exc)})
                self.send_json({
                    "ok": len(errors) == 0,
                    "installed": installed,
                    "unavailable": unavailable,
                    "errors": errors
                }, status=200 if not errors else 500)
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, status=500)
            return
        if parsed.path == "/api/update/restart":
            self.send_json({
                "ok": True,
                "restarting": False,
                "message": "Seit 0.23.2.7 übernimmt /api/update/install den Neustart automatisch."
            })
            return
        if parsed.path == "/api/update/install":
            try:
                manifest = fetch_update_manifest()
                result = prepare_update_handoff(manifest)
                self.send_json(result)
                request_process_exit(1.4)
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, status=500)
            return
        if parsed.path == "/api/panel/convert":
            try:
                rgba = self.read_body(max_bytes=RGBA_BYTES)
                if len(rgba) != RGBA_BYTES:
                    return self.send_json({
                        "error": f"expected {RGBA_BYTES} RGBA bytes",
                        "received": len(rgba)
                    }, 400)
                panel = rgba_to_panel_bin(rgba)
                if len(panel) != PANEL_BYTES:
                    return self.send_json({"error": "panel encoder returned wrong size"}, 500)
                CURRENT_PANEL.write_bytes(panel)
                digest = sha256_hex(panel)
                return self.send_json({
                    "ok": True,
                    "bytes": len(panel),
                    "sha256": digest,
                    "download_url": "/api/panel/current.bin"
                })
            except Exception as exc:
                return self.send_json({"error": f"{type(exc).__name__}: {exc}"}, 500)


        if parsed.path == "/api/library/patch":
            qs = urllib.parse.parse_qs(parsed.query)
            code = sanitize_designator(qs.get("type", [""])[0])
            if not code:
                return self.send_json({"error": "Ungültiger ICAO-Typcode."}, 400)
            try:
                raw = self.read_body(max_bytes=16_000_000)
                if len(raw) < 24 or raw[:8] != b"\x89PNG\r\n\x1a\n":
                    return self.send_json({"error": "Nur echte PNG-Dateien sind erlaubt."}, 400)
                # Decode once with Pillow to reject malformed or deceptive uploads.
                from PIL import Image
                import io
                with Image.open(io.BytesIO(raw)) as im:
                    im.verify()
                base_dir = ROOT / "assets" / "aircraft" / "base"
                base_dir.mkdir(parents=True, exist_ok=True)
                target = base_dir / f"{code}_base.png"
                _atomic_write_bytes(target, raw)
                with _AIRCRAFT_MAPPING_LOCK:
                    mapping = load_aircraft_mapping()
                    mapping.setdefault("assets", {})[code] = f"assets/aircraft/base/{code}_base.png"
                    mapping.setdefault("aliases", {})[code] = code
                    save_aircraft_mapping(mapping)
                _remove_missing_aircraft(code)
                return self.send_json({
                    "ok": True,
                    "type": code,
                    "asset": f"assets/aircraft/base/{code}_base.png",
                    "message": f"{code} wurde gepatcht und ist sofort aktiv."
                })
            except Exception as exc:
                return self.send_json({"error": f"Patch fehlgeschlagen: {type(exc).__name__}: {exc}"}, 500)

        return self.send_json({"detail": "unknown endpoint"}, 404)

    def end_headers(self):
        path = urllib.parse.urlparse(self.path).path.lower()

        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")

        # HTML and API responses must never stick across an update.
        if path in ("/", "/index.html") or path.startswith("/api/"):
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
        # Versioned JS/CSS may be cached aggressively because the ?v= changes per release.
        elif path.endswith((".js", ".css")):
            self.send_header("Cache-Control", "public, max-age=31536000, immutable")
        # Other local static files are revalidated instead of blindly reused.
        else:
            self.send_header("Cache-Control", "no-cache, must-revalidate")
        super().end_headers()

    def do_GET(self):
        if not self.request_host_allowed():
            return self.send_json({"error": "Nicht erlaubter Host."}, 403)
        if self.path.startswith("/api/assets/missing-availability"):
            try:
                manifest = fetch_remote_asset_manifest()
                index = remote_asset_index(manifest)
                missing = missing_aircraft_status()
                result = []
                for row in missing:
                    code = str(row.get("type") or "").upper()
                    item = index.get(code)
                    result.append({
                        "code": code,
                        "available": bool(item),
                        "remote": {
                            "path": item.get("path"),
                            "type": item.get("type", "aircraft")
                        } if item else None
                    })
                self.send_json({"ok": True, "items": result})
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, status=502)
            return
        if self.path.startswith("/api/assets/remote"):
            try:
                manifest = fetch_remote_asset_manifest()
                index = remote_asset_index(manifest)
                self.send_json({"ok": True, "count": len(index), "assets": list(index.values())})
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, status=502)
            return
        if self.path.startswith("/api/update/status"):
            last_update = None
            try:
                if UPDATE_STATUS_FILE.exists():
                    last_update = json.loads(UPDATE_STATUS_FILE.read_text(encoding="utf-8-sig"))
            except Exception:
                last_update = None
            restart_log = ""
            try:
                log_path = RUNTIME_DIR / "restart.log"
                if log_path.exists():
                    restart_log = "\n".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-8:])
            except Exception:
                restart_log = ""
            return self.send_json({
                "ok": True,
                "version": read_local_version(),
                "pid": os.getpid(),
                "last_update": last_update,
                "restart_log": restart_log
            })
        if self.path.startswith("/api/update/check"):
            try:
                manifest = fetch_update_manifest()
                self.send_json(manifest)
            except Exception as exc:
                self.send_json({"error": str(exc)}, status=502)
            return
        parsed = urllib.parse.urlparse(self.path)

        if parsed.path == "/api/panel/current.bin":
            if not CURRENT_PANEL.exists():
                return self.send_json({"error": "no panel image exported yet"}, 404)
            panel = CURRENT_PANEL.read_bytes()
            if len(panel) != PANEL_BYTES:
                return self.send_json({"error": "current panel image has wrong size"}, 503)
            return self.send_bytes(
                panel,
                "application/octet-stream",
                cache_seconds=0,
                extra_headers={"Content-Disposition": 'attachment; filename="aerofolio-panel.bin"'}
            )


        if parsed.path == "/api/library/status":
            assets = library_status()
            return self.send_json({
                "assets": assets,
                "available_count": sum(1 for v in assets.values() if v),
                "total_count": len(assets),
                "observed_missing_count": len(missing_aircraft_status())
            })

        if parsed.path == "/api/library/missing":
            return self.send_json({
                "missing": missing_aircraft_status(),
                "count": len(missing_aircraft_status())
            })

        if parsed.path == "/api/library/patch-token-hint":
            # Never expose the token itself over HTTP. Only tell the operator where it is stored.
            return self.send_json({
                "token_file": "runtime/patch_token.txt",
                "env_override": "AEROFOLIO_PATCH_TOKEN"
            })

        if parsed.path == "/api/health":
            return self.send_json({"ok": True, "service": "AEROFOLIO V22.2"})


        if parsed.path == "/api/vintage-profile":
            qs = urllib.parse.parse_qs(parsed.query)
            designator = clean_aircraft_designator(qs.get("type", [""])[0])
            airline = (qs.get("airline", [""])[0] or "").strip()
            asset, file_path = resolve_local_asset(designator)
            if not asset or not file_path:
                return self.send_json({
                    "error": "AEROFOLIO base illustration missing",
                    "type": designator,
                    "airline": airline,
                    "needed": True
                }, 404)

            data = file_path.read_bytes()
            suffix = file_path.suffix.lower()
            ctype = {
                ".png": "image/png",
                ".webp": "image/webp",
                ".jpg": "image/jpeg",
                ".jpeg": "image/jpeg",
            }.get(suffix, "application/octet-stream")
            return self.send_bytes(data, ctype, cache_seconds=3600)


        if parsed.path == "/api/live":
            qs = urllib.parse.parse_qs(parsed.query)
            try:
                lat = float(qs.get("lat", [""])[0])
                lon = float(qs.get("lon", [""])[0])
                radius_km = float(qs.get("radius_km", ["25"])[0])
            except ValueError:
                return self.send_json({"error": "Ungültige Koordinaten oder Radius."}, 400)

            if not all(math.isfinite(value) for value in (lat, lon, radius_km)):
                return self.send_json({"error": "Koordinaten und Radius müssen endliche Zahlen sein."}, 400)

            if not (-90 <= lat <= 90 and -180 <= lon <= 180):
                return self.send_json({"error": "Koordinaten außerhalb des gültigen Bereichs."}, 400)

            radius_km = max(1.0, min(radius_km, 463.0))
            radius_nm = max(1, min(250, math.ceil(radius_km / 1.852)))

            adsb = provider_request(ADSB_BASE, lat, lon, radius_nm, "adsb.lol")
            provider_summary = {
                "ok": adsb["ok"],
                "count": adsb["count"],
                "error": adsb["error"],
                "elapsed_ms": adsb["elapsed_ms"],
            }
            query = {
                "lat": lat,
                "lon": lon,
                "radius_km": radius_km,
                "radius_nm": radius_nm,
            }
            if not adsb["ok"]:
                return self.send_json({
                    "ok": False,
                    "error": "ADSB.lol ist derzeit nicht erreichbar.",
                    "query": query,
                    "providers": {"adsb_lol": provider_summary},
                    "merged_count": 0,
                    "aircraft": [],
                    "generated_at": time.time(),
                }, 502)

            aircraft = merge_aircraft(adsb["aircraft"])
            record_missing_aircraft(aircraft)

            return self.send_json({
                "ok": True,
                "query": query,
                "providers": {"adsb_lol": provider_summary},
                "merged_count": len(aircraft),
                "aircraft": aircraft,
                "generated_at": time.time(),
            })

        if public_path_for_request(self.path) is None:
            return self.send_json({"error": "Datei nicht freigegeben."}, 404)
        return super().do_GET()

    def do_HEAD(self):
        if not self.request_host_allowed():
            self.send_error(403, "Nicht erlaubter Host")
            return
        if public_path_for_request(self.path) is None:
            self.send_error(404, "Datei nicht freigegeben")
            return
        return super().do_HEAD()

if __name__ == "__main__":
    os.chdir(ROOT)
    read_local_version()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print()
    print(f"AEROFOLIO {read_local_version()}")
    print(f"Server läuft auf http://localhost:{PORT}")
    print("Live-Datenquelle: ADSB.lol")
    get_patch_token()
    print("Administrations-Token wurde lokal bereitgestellt.")
    print(f"Patch-Token-Datei: {PATCH_TOKEN_FILE}")
    print("Zum Beenden dieses Fenster schließen oder STRG+C drücken.")
    print()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer beendet.")
