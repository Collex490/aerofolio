@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py tools\build_asset_inventory.py %*
) else (
  python tools\build_asset_inventory.py %*
)
if errorlevel 1 echo Inventarpruefung fehlgeschlagen.
pause
