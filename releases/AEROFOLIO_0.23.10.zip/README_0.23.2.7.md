# AEROFOLIO 0.23.2.7

## Neuer Update-Ablauf

Der zentrale Unterschied zu 0.23.2.6:

**Der laufende Python-Server ersetzt seine eigenen Dateien nicht mehr selbst.**

Ablauf:
1. `/api/update/install` lädt das Release-ZIP herunter.
2. SHA-256 wird geprüft.
3. Ein unabhängiger Helper wird nach `runtime/update_handoff.py` geschrieben.
4. Der Browser erhält die Bestätigung.
5. Der alte Server beendet sich.
6. Erst jetzt ersetzt der Helper die Programmdateien.
7. Vorher wird ein Backup unter `runtime/backups/` angelegt.
8. Der Helper startet den neuen Server.
9. Der Browser wartet auf die neue Versionsnummer.
10. Die Seite lädt sich automatisch neu.

## Rollback
Wenn der neue Server nach der Installation nicht erreichbar wird:
- neuer Prozess wird beendet,
- vorherige Dateien werden aus dem Backup zurückkopiert,
- alte Versionsnummer wird wiederhergestellt,
- alter Server wird wieder gestartet.

Diagnose:
`runtime/update_handoff.log`

Status:
`runtime/last_update.json`

## Wichtiger Übergang
Der Sprung **0.23.2.6 -> 0.23.2.7** wird noch vom alten 0.23.2.6-Updater
gestartet. Deshalb kann genau bei diesem einen Übergang nochmals ein manueller
Reload nötig sein.

Ab **0.23.2.7 -> 0.23.2.8** wird der neue Handoff-Updater vollständig getestet.
