AEROFOLIO V23.2.1 – Remote Update Test

Zweck:
- Testet den vollständigen Remote-Update-Weg von V23.2.0 auf V23.2.1.

Sichtbare Teständerung:
- Unten rechts erscheint nach erfolgreichem Update:
  "Remote Update erfolgreich · 23.2.1"

Nach erfolgreichem Test kann dieser Hinweis in der nächsten Version wieder entfernt werden.
