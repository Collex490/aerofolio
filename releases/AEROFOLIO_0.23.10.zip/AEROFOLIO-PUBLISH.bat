@echo off
setlocal
title AEROFOLIO Release Publisher
echo.
echo ========================================
echo        AEROFOLIO RELEASE PUBLISHER
echo ========================================
echo.
set /p ZIP=ZIP vollstaendig hierher ziehen und Enter: 
set /p VER=Version eingeben (z.B. 0.23.2.4): 
set ZIP=%ZIP:"=%
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0publish-release.ps1" "%ZIP%" "%VER%"
echo.
pause
