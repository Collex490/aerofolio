# AEROFOLIO 0.23.2.8

Reiner Live-Test des in 0.23.2.7 eingeführten Handoff-Updaters.

Es wurden absichtlich keine funktionalen Änderungen am Updater vorgenommen.
Testziel:
0.23.2.7 -> Update installieren -> externer Helper übernimmt -> neuer Server
startet -> Browser zeigt 0.23.2.8 automatisch, ohne Strg+F5.
