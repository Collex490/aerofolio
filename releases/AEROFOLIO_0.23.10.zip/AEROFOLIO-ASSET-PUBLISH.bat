@echo off
setlocal
title AEROFOLIO Asset Publisher
echo.
echo ========================================
echo         AEROFOLIO ASSET PUBLISHER
echo ========================================
echo.
set /p PNG=PNG hierher ziehen und Enter: 
set /p CODE=ICAO-Typcode eingeben (z.B. B77L): 
set PNG=%PNG:"=%
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0publish-aircraft-base.ps1" "%PNG%" "%CODE%"
echo.
pause
