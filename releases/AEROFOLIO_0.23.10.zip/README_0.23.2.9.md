# AEROFOLIO 0.23.2.9

Reiner Handoff-Updater-Test.

Ausgangslage:
0.23.2.8 wurde nach vollständigem Beenden der alten Python-Prozesse frisch gestartet.
Damit läuft nun erstmals sicher der neue Handoff-Code.

Testziel:
0.23.2.8 -> 0.23.2.9 vollständig automatisch:
- Update herunterladen und SHA-256 prüfen
- alter Server beendet sich
- externer Helper übernimmt
- Backup und Dateiaustausch
- neuer Server startet
- Browser erkennt 0.23.2.9
- automatische Aktualisierung ohne Strg+F5
