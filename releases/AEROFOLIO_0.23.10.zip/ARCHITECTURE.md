# AEROFOLIO V22 Architecture

ADSB.lol -> `server.py` normalize -> `/api/live` -> Browser-App -> eigener Poster-Renderer.

Artwork: `/api/vintage-profile?type=...` -> `data/aircraft_mapping.json` -> `assets/aircraft/base/*_base.png`.

Poster-Layout, Textanker, Einzelpositionierung, Größen- und Abstandskontrollen laufen vollständig lokal in `app.js`.
