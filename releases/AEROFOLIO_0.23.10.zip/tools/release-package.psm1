Set-StrictMode -Version Latest

$script:RequiredReleaseFiles = @(
    "app.js",
    "index.html",
    "server.py",
    "start.bat",
    "styles.css",
    "engines/__init__.py",
    "engines/panel_codec.py"
)

$script:OptionalRootFiles = @(
    "AEROFOLIO-ASSET-PUBLISH.bat",
    "AEROFOLIO-PUBLISH.bat",
    "ARCHITECTURE.md",
    "publish-aircraft-base.ps1",
    "publish-release.ps1",
    "README.md",
    "refresh_asset_inventory.bat",
    "THIRD_PARTY_NOTICES.txt"
)

$script:RequiredPackageFiles = $script:RequiredReleaseFiles + @("release.json")

$script:OptionalToolFiles = @(
    "tools/AEROFOLIO-ASSET-PUBLISH.bat",
    "tools/AEROFOLIO-PUBLISH.bat",
    "tools/build-release.ps1",
    "tools/build_asset_inventory.py",
    "tools/publish-aircraft-base.ps1",
    "tools/publish-release.ps1",
    "tools/release-package.psm1"
)

function ConvertTo-ReleasePath {
    param([Parameter(Mandatory = $true)][string]$Path)
    return ($Path -replace "\\", "/").TrimStart("/")
}

function Test-ReleasePathAllowed {
    param([Parameter(Mandatory = $true)][string]$Path)

    $relative = ConvertTo-ReleasePath $Path
    if ($script:RequiredReleaseFiles -contains $relative) { return $true }
    if ($relative -eq 'release.json') { return $true }
    if ($script:OptionalRootFiles -contains $relative) { return $true }
    if ($script:OptionalToolFiles -contains $relative) { return $true }
    if ($relative -match '^README[^/]*\.(md|txt)$') { return $true }
    if ($relative -match '^engines/[^/]+\.py$') { return $true }
    return $false
}

function Assert-SafeReleasePath {
    param([Parameter(Mandatory = $true)][string]$Path)

    $relative = ConvertTo-ReleasePath $Path
    if (-not $relative -or $relative -match '^[A-Za-z]:' -or $Path -match '^[\\/]') {
        throw "Unsicherer oder absoluter ZIP-Pfad: $Path"
    }

    $segments = @($relative.Split('/') | Where-Object { $_ -ne '' })
    if ($segments -contains '.' -or $segments -contains '..') {
        throw "Unsicherer ZIP-Pfad: $Path"
    }

    $forbiddenDirectories = @(
        '.git', '.github', '.idea', '.mypy_cache', '.pytest_cache', '.ruff_cache',
        '.venv', '.vscode', '__pycache__', 'assets', 'backups', 'data', 'dist',
        'releases', 'runtime', 'updates', 'venv'
    )
    foreach ($segment in $segments) {
        if ($forbiddenDirectories -contains $segment.ToLowerInvariant()) {
            throw "Verbotener Bereich im Releasepaket: $relative"
        }
        if ($segment -match '^(aerofolio-(stage|handoff)-|update-)') {
            throw "Laufzeit- oder Staging-Pfad im Releasepaket: $relative"
        }
    }

    $leaf = if ($segments.Count) { $segments[-1] } else { '' }
    if ($leaf -match '(?i)(patch[_-]?token|secret|credential|password|private[_-]?key)') {
        throw "Potenziell sensible Datei im Releasepaket: $relative"
    }
    if ($leaf -match '(?i)\.(bak|log|pyc|pyo|tmp|zip)$') {
        throw "Verbotener Dateityp im Releasepaket: $relative"
    }
}

function Get-AerofolioReleaseFiles {
    param([Parameter(Mandatory = $true)][string]$ProjectRoot)

    $root = (Resolve-Path -LiteralPath $ProjectRoot).Path
    $relativeFiles = @()

    foreach ($relative in $script:RequiredReleaseFiles) {
        $source = Join-Path $root ($relative -replace '/', [IO.Path]::DirectorySeparatorChar)
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
            throw "Erforderliche Release-Datei fehlt: $relative"
        }
        $relativeFiles += $relative
    }

    foreach ($relative in ($script:OptionalRootFiles + $script:OptionalToolFiles)) {
        $source = Join-Path $root ($relative -replace '/', [IO.Path]::DirectorySeparatorChar)
        if (Test-Path -LiteralPath $source -PathType Leaf) {
            $relativeFiles += $relative
        }
    }

    Get-ChildItem -LiteralPath $root -File | Where-Object {
        $_.Name -match '^README.*\.(md|txt)$'
    } | ForEach-Object {
        $relativeFiles += $_.Name
    }

    Get-ChildItem -LiteralPath (Join-Path $root 'engines') -File -Filter '*.py' | ForEach-Object {
        $relativeFiles += "engines/$($_.Name)"
    }

    $result = @()
    foreach ($relative in ($relativeFiles | Sort-Object -Unique)) {
        Assert-SafeReleasePath $relative
        if (-not (Test-ReleasePathAllowed $relative)) {
            throw "Datei steht nicht auf der Release-Zulassungsliste: $relative"
        }
        $result += [PSCustomObject]@{
            RelativePath = $relative
            SourcePath = Join-Path $root ($relative -replace '/', [IO.Path]::DirectorySeparatorChar)
        }
    }
    return $result
}

function Test-AerofolioReleasePackage {
    param(
        [Parameter(Mandatory = $true)][string]$ZipPath,
        [string]$ExpectedVersion
    )

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $resolvedZip = (Resolve-Path -LiteralPath $ZipPath).Path
    $archive = [System.IO.Compression.ZipFile]::OpenRead($resolvedZip)
    try {
        $files = @($archive.Entries | Where-Object { -not $_.FullName.EndsWith('/') })
        if ($files.Count -gt 500) {
            throw "Releasepaket enthält zu viele Dateien: $($files.Count)"
        }

        $totalBytes = ($files | Measure-Object -Property Length -Sum).Sum
        if ($null -eq $totalBytes) { $totalBytes = 0 }
        if ($totalBytes -gt 100MB) {
            throw "Releasepaket ist entpackt größer als 100 MiB."
        }

        $present = @{}
        foreach ($entry in $files) {
            $relative = ConvertTo-ReleasePath $entry.FullName
            Assert-SafeReleasePath $entry.FullName
            if (-not (Test-ReleasePathAllowed $relative)) {
                throw "Nicht zugelassene Datei im Releasepaket: $relative"
            }

            $unixType = (($entry.ExternalAttributes -shr 16) -band 0xF000)
            if ($unixType -eq 0xA000) {
                throw "Symbolische Links sind im Releasepaket nicht erlaubt: $relative"
            }
            if ($present.ContainsKey($relative.ToLowerInvariant())) {
                throw "Doppelter ZIP-Eintrag: $relative"
            }
            $present[$relative.ToLowerInvariant()] = $true
        }

        foreach ($required in $script:RequiredPackageFiles) {
            if (-not $present.ContainsKey($required.ToLowerInvariant())) {
                throw "Erforderliche Datei fehlt im Releasepaket: $required"
            }
        }

        $metadataEntry = $files | Where-Object { (ConvertTo-ReleasePath $_.FullName) -eq 'release.json' } | Select-Object -First 1
        if ($metadataEntry.Length -gt 4096) {
            throw "release.json ist unerwartet groß."
        }
        $metadataStream = $metadataEntry.Open()
        $metadataReader = New-Object IO.StreamReader($metadataStream, [Text.Encoding]::UTF8, $true)
        try {
            $metadata = $metadataReader.ReadToEnd() | ConvertFrom-Json
        }
        finally {
            $metadataReader.Dispose()
            $metadataStream.Dispose()
        }
        if ($metadata.product -ne 'AEROFOLIO' -or $metadata.format -ne 1) {
            throw "Ungültige Release-Metadaten."
        }
        $packageVersion = [string]$metadata.version
        if ($packageVersion -notmatch '^\d+\.\d+\.\d+(?:\.\d+)?$') {
            throw "Ungültige Version in release.json."
        }
        if ($ExpectedVersion -and $packageVersion -ne $ExpectedVersion) {
            throw "Paketversion $packageVersion stimmt nicht mit $ExpectedVersion überein."
        }

        return [PSCustomObject]@{
            ZipPath = $resolvedZip
            Version = $packageVersion
            FileCount = $files.Count
            UncompressedBytes = [long]$totalBytes
            Sha256 = (Get-FileHash -LiteralPath $resolvedZip -Algorithm SHA256).Hash.ToUpperInvariant()
        }
    }
    finally {
        $archive.Dispose()
    }
}

function New-AerofolioReleasePackage {
    param(
        [Parameter(Mandatory = $true)][string]$ProjectRoot,
        [Parameter(Mandatory = $true)][string]$OutputPath,
        [Parameter(Mandatory = $true)][string]$Version
    )

    if ($Version -notmatch '^\d+\.\d+\.\d+(?:\.\d+)?$') {
        throw "Ungültige Version: $Version"
    }

    $root = (Resolve-Path -LiteralPath $ProjectRoot).Path
    $outputFullPath = [IO.Path]::GetFullPath($OutputPath)
    $protectedRoots = @('runtime', 'data', 'assets') | ForEach-Object {
        [IO.Path]::GetFullPath((Join-Path $root $_)).TrimEnd('\') + '\'
    }
    foreach ($protectedRoot in $protectedRoots) {
        if ($outputFullPath.StartsWith($protectedRoot, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Releasepaket darf nicht in einen geschützten Projektbereich geschrieben werden."
        }
    }

    $files = @(Get-AerofolioReleaseFiles -ProjectRoot $root)
    $outputDirectory = Split-Path -Parent $outputFullPath
    if (-not (Test-Path -LiteralPath $outputDirectory)) {
        New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
    }

    $stage = Join-Path ([IO.Path]::GetTempPath()) ("aerofolio-release-" + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $stage | Out-Null
    try {
        foreach ($file in $files) {
            $destination = Join-Path $stage ($file.RelativePath -replace '/', [IO.Path]::DirectorySeparatorChar)
            $destinationDirectory = Split-Path -Parent $destination
            if (-not (Test-Path -LiteralPath $destinationDirectory)) {
                New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
            }
            Copy-Item -LiteralPath $file.SourcePath -Destination $destination
        }

        [ordered]@{
            product = 'AEROFOLIO'
            version = $Version
            format = 1
        } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $stage 'release.json') -Encoding UTF8

        if (Test-Path -LiteralPath $outputFullPath) {
            Remove-Item -LiteralPath $outputFullPath -Force
        }
        Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $outputFullPath -CompressionLevel Optimal
        return Test-AerofolioReleasePackage -ZipPath $outputFullPath -ExpectedVersion $Version
    }
    finally {
        if (Test-Path -LiteralPath $stage) {
            Remove-Item -LiteralPath $stage -Recurse -Force
        }
    }
}

Export-ModuleMember -Function New-AerofolioReleasePackage, Test-AerofolioReleasePackage
