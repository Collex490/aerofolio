param(
    [Parameter(Mandatory = $true, Position = 0)][string]$Version,
    [string]$ProjectRoot = (Split-Path $PSScriptRoot -Parent),
    [string]$OutputPath
)

$ErrorActionPreference = "Stop"
if ($Version -notmatch '^\d+\.\d+\.\d+(?:\.\d+)?$') {
    throw "Ungültige Version: $Version"
}

$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
if (-not $OutputPath) {
    $OutputPath = Join-Path $ProjectRoot "dist\AEROFOLIO_$Version.zip"
}

Import-Module (Join-Path $PSScriptRoot 'release-package.psm1') -Force
$result = New-AerofolioReleasePackage -ProjectRoot $ProjectRoot -OutputPath $OutputPath -Version $Version

Write-Host "Releasepaket lokal erstellt und geprüft:" -ForegroundColor Green
Write-Host $result.ZipPath
Write-Host "Dateien: $($result.FileCount)"
Write-Host "SHA256: $($result.Sha256)"
