﻿param(
 [Parameter(Mandatory=$true,Position=0)][string]$PngPath,
 [Parameter(Mandatory=$true,Position=1)][string]$Code,
 [string]$RepoRoot=(Split-Path $PSScriptRoot -Parent)
)
$ErrorActionPreference="Stop"
function Fail($m){Write-Host "FEHLER: $m" -ForegroundColor Red; pause; exit 1}
try{$PngPath=(Resolve-Path $PngPath).Path}catch{Fail "PNG nicht gefunden: $PngPath"}
if([IO.Path]::GetExtension($PngPath).ToLower() -ne ".png"){Fail "Nur PNG-Dateien sind erlaubt."}
$Code=$Code.Trim().ToUpperInvariant()
if($Code -notmatch '^[A-Z0-9]{2,8}$'){Fail "Ungueltiger ICAO-Typcode."}
if(-not(Test-Path(Join-Path $RepoRoot ".git"))){Fail "Git-Repo fehlt: $RepoRoot"}
Set-Location $RepoRoot
if(git status --porcelain){Fail "Git-Repo hat uncommittete Aenderungen."}

$rel="aircraft/base/${Code}_base.png"
$dest=Join-Path $RepoRoot "assets\$rel"
New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
Copy-Item $PngPath $dest -Force
$hash=(Get-FileHash $dest -Algorithm SHA256).Hash.ToUpperInvariant()
$url="https://raw.githubusercontent.com/Collex490/aerofolio/main/assets/$rel"

$manifestPath=Join-Path $RepoRoot "assets\manifest.json"
if(Test-Path $manifestPath){
  try{$manifest=Get-Content $manifestPath -Raw | ConvertFrom-Json}catch{$manifest=$null}
}
if($null -eq $manifest){$manifest=[PSCustomObject]@{}}

$assets=@()
if($null -ne $manifest.assets){$assets=@($manifest.assets)}
$assets=@($assets | Where-Object { $_.key -ne $Code })
$assets += [PSCustomObject]@{
  key=$Code
  type="aircraft"
  path=$rel
  url=$url
  sha256=$hash
}
$manifest | Add-Member -Force NoteProperty version 1
$manifest | Add-Member -Force NoteProperty assets $assets
if($null -eq $manifest.aircraft_bases){$manifest | Add-Member -Force NoteProperty aircraft_bases @()}
if($null -eq $manifest.liveries){$manifest | Add-Member -Force NoteProperty liveries @()}
if($null -eq $manifest.logos){$manifest | Add-Member -Force NoteProperty logos @()}
$manifest | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 $manifestPath

git add "assets/manifest.json" "assets/$rel"
git commit -m "Add AEROFOLIO aircraft base $Code"
if($LASTEXITCODE-ne 0){Fail "Commit fehlgeschlagen"}
git push
if($LASTEXITCODE-ne 0){Fail "Push fehlgeschlagen"}

Write-Host ""
Write-Host "Base $Code erfolgreich veroeffentlicht!" -ForegroundColor Green
Write-Host "SHA256: $hash"
