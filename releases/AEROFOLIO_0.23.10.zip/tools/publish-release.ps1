param(
    [Parameter(Mandatory = $true, Position = 0)][string]$ZipPath,
    [Parameter(Mandatory = $true, Position = 1)][string]$Version,
    [string]$RepoRoot = (Split-Path $PSScriptRoot -Parent)
)

$ErrorActionPreference = "Stop"
function Fail([string]$Message) {
    throw $Message
}

if ($Version -notmatch '^\d+\.\d+\.\d+(?:\.\d+)?$') {
    Fail "Ungültige Version: $Version"
}
try { $ZipPath = (Resolve-Path -LiteralPath $ZipPath).Path } catch { Fail "ZIP nicht gefunden: $ZipPath" }
try { $RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path } catch { Fail "Repository nicht gefunden: $RepoRoot" }

Import-Module (Join-Path $PSScriptRoot 'release-package.psm1') -Force
$package = Test-AerofolioReleasePackage -ZipPath $ZipPath -ExpectedVersion $Version

if (-not (Test-Path -LiteralPath (Join-Path $RepoRoot '.git'))) {
    Fail "Git-Repo fehlt: $RepoRoot"
}

Push-Location $RepoRoot
try {
    if (git status --porcelain) { Fail "Git-Repo hat uncommittete Änderungen." }

    $name = "AEROFOLIO_$Version.zip"
    $releaseDirectory = Join-Path $RepoRoot 'releases'
    New-Item -ItemType Directory -Path $releaseDirectory -Force | Out-Null
    $destination = Join-Path $releaseDirectory $name
    Copy-Item -LiteralPath $ZipPath -Destination $destination -Force

    $copiedPackage = Test-AerofolioReleasePackage -ZipPath $destination -ExpectedVersion $Version
    if ($copiedPackage.Sha256 -ne $package.Sha256) {
        Fail "Prüfsumme hat sich beim Kopieren verändert."
    }

    $manifest = [ordered]@{
        product = "AEROFOLIO"
        channel = "stable"
        latest = $Version
        minimum_supported = "0.23.2.3"
        package_url = "https://raw.githubusercontent.com/Collex490/aerofolio/main/releases/$name"
        sha256 = $copiedPackage.Sha256
        mandatory = $false
        notes = "AEROFOLIO Release $Version"
        asset_manifest_url = "https://raw.githubusercontent.com/Collex490/aerofolio/main/assets/manifest.json"
    }
    $manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $RepoRoot 'latest.json') -Encoding UTF8

    git diff --check
    if ($LASTEXITCODE -ne 0) { Fail "Git-Prüfung fehlgeschlagen." }
    git add -- 'latest.json' "releases/$name"
    if ($LASTEXITCODE -ne 0) { Fail "Git-Staging fehlgeschlagen." }
    git commit -m "Release AEROFOLIO v$Version"
    if ($LASTEXITCODE -ne 0) { Fail "Commit fehlgeschlagen." }
    git push
    if ($LASTEXITCODE -ne 0) { Fail "Push fehlgeschlagen." }

    Write-Host "Release $Version erfolgreich veröffentlicht." -ForegroundColor Green
    Write-Host "SHA256: $($copiedPackage.Sha256)"
}
finally {
    Pop-Location
}
