from __future__ import annotations

import argparse
from collections import deque
import hashlib
import json
from pathlib import Path
import time

from PIL import Image, UnidentifiedImageError


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
BASE_DIR = ROOT / "assets" / "aircraft" / "base"
LIVERY_DIR = ROOT / "assets" / "liveries"
LOGO_DIR = ROOT / "assets" / "logos"
INVENTORY_PATH = DATA_DIR / "asset_inventory.json"


def load_json(path: Path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Ungueltige JSON-Datei: {path.relative_to(ROOT)}: {exc}") from exc


def normalized_missing_records(raw) -> dict[str, dict]:
    if isinstance(raw, dict) and isinstance(raw.get("missing"), (dict, list)):
        raw = raw["missing"]
    if isinstance(raw, dict):
        return {
            str(code).strip().upper(): value if isinstance(value, dict) else {}
            for code, value in raw.items()
            if str(code).strip()
        }
    if isinstance(raw, list):
        result = {}
        for value in raw:
            if isinstance(value, dict):
                code = value.get("type") or value.get("icao")
                record = value
            else:
                code = value
                record = {}
            code = str(code or "").strip().upper()
            if code:
                result[code] = record
        return result
    return {}


def component_ratios(alpha: Image.Image) -> list[float]:
    """Return ratios of disconnected visible regions on a small alpha mask."""
    probe = alpha.copy()
    probe.thumbnail((512, 256), Image.Resampling.NEAREST)
    width, height = probe.size
    visible = bytearray(1 if value > 32 else 0 for value in probe.tobytes())
    components = []

    for start, value in enumerate(visible):
        if not value:
            continue
        visible[start] = 0
        queue = deque([start])
        size = 0
        while queue:
            point = queue.popleft()
            size += 1
            x, y = point % width, point // width
            for nx, ny in (
                (x - 1, y - 1), (x, y - 1), (x + 1, y - 1),
                (x - 1, y),                     (x + 1, y),
                (x - 1, y + 1), (x, y + 1), (x + 1, y + 1),
            ):
                if 0 <= nx < width and 0 <= ny < height:
                    neighbour = ny * width + nx
                    if visible[neighbour]:
                        visible[neighbour] = 0
                        queue.append(neighbour)
        components.append(size)

    components.sort(reverse=True)
    if not components or components[0] == 0:
        return []
    largest = components[0]
    return [round(value / largest, 4) for value in components[:8]]


def validate_png(path: Path, manual_review: dict) -> dict:
    code = path.name.removesuffix("_base.png").upper()
    result = {
        "path": path.relative_to(ROOT).as_posix(),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "readable": False,
        "issues": [],
    }
    automatic_issues = []

    try:
        with Image.open(path) as check:
            check.verify()
        with Image.open(path) as source:
            source.load()
            width, height = source.size
            format_name = source.format
            mode = source.mode
            bands = source.getbands()
            has_transparency_info = "transparency" in source.info
            rgba = source.convert("RGBA")
    except (OSError, UnidentifiedImageError, ValueError) as exc:
        result["issues"] = ["unreadable_png"]
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result

    alpha = rgba.getchannel("A")
    histogram = alpha.histogram()
    pixel_count = width * height
    edge_values = (
        list(alpha.crop((0, 0, width, 1)).tobytes())
        + list(alpha.crop((0, height - 1, width, height)).tobytes())
        + list(alpha.crop((0, 0, 1, height)).tobytes())
        + list(alpha.crop((width - 1, 0, width, height)).tobytes())
    )
    component_sizes = component_ratios(alpha)
    detached_components = [ratio for ratio in component_sizes[1:] if ratio >= 0.015]

    has_alpha = "A" in bands or has_transparency_info
    aspect_ratio = width / height if height else 0
    transparent_fraction = sum(histogram[:9]) / pixel_count
    low_alpha_fraction = sum(histogram[1:65]) / pixel_count
    semi_transparent_fraction = sum(histogram[9:240]) / pixel_count
    edge_transparent_fraction = (
        sum(1 for value in edge_values if value <= 8) / len(edge_values)
        if edge_values else 0
    )

    if format_name != "PNG":
        automatic_issues.append("not_png")
    if not has_alpha or alpha.getextrema()[0] == 255:
        automatic_issues.append("missing_transparency")
    if width < 1000 or height < 500 or width > 4096 or height > 2048:
        automatic_issues.append("implausible_dimensions")
    if not 1.8 <= aspect_ratio <= 3.5:
        automatic_issues.append("implausible_aspect_ratio")
    if edge_transparent_fraction < 0.80:
        automatic_issues.append("nontransparent_canvas_edge")
    if low_alpha_fraction > 0.08 or semi_transparent_fraction > 0.30:
        automatic_issues.append("possible_large_background")
    if detached_components:
        automatic_issues.append("possible_detached_label_or_artwork")

    review = manual_review.get(code, {}) if isinstance(manual_review, dict) else {}
    manual_issues = [str(value) for value in review.get("issues", [])]
    issues = list(dict.fromkeys(automatic_issues + manual_issues))
    result.update({
        "readable": True,
        "format": format_name,
        "mode": mode,
        "width": width,
        "height": height,
        "aspect_ratio": round(aspect_ratio, 4),
        "has_alpha": has_alpha,
        "alpha_extrema": list(alpha.getextrema()),
        "transparent_fraction": round(transparent_fraction, 4),
        "low_alpha_fraction": round(low_alpha_fraction, 4),
        "semi_transparent_fraction": round(semi_transparent_fraction, 4),
        "edge_transparent_fraction": round(edge_transparent_fraction, 4),
        "component_ratios": component_sizes,
        "automatic_issues": automatic_issues,
        "manual_status": review.get("status", "unreviewed"),
        "manual_note": review.get("note", ""),
        "issues": issues,
    })
    return result


def listed_pngs(directory: Path) -> list[str]:
    if not directory.exists():
        return []
    return sorted(path.relative_to(directory).as_posix() for path in directory.rglob("*.png"))


def build_inventory() -> dict:
    mapping = load_json(DATA_DIR / "aircraft_mapping.json", {"assets": {}, "aliases": {}})
    missing_records = normalized_missing_records(load_json(DATA_DIR / "missing_aircraft.json", {}))
    manual_review = load_json(DATA_DIR / "asset_review.json", {})

    base_files = sorted(BASE_DIR.glob("*_base.png"))
    present = [path.name.removesuffix("_base.png").upper() for path in base_files]
    present_set = set(present)
    mapped_assets = {
        str(code).upper(): str(relative_path)
        for code, relative_path in mapping.get("assets", {}).items()
    }
    aliases = {
        str(code).upper(): str(target).upper()
        for code, target in mapping.get("aliases", {}).items()
    }

    missing_exact = sorted(code for code in missing_records if code not in present_set)
    fallback_covered = []
    missing_uncovered = []
    for code in missing_exact:
        target = aliases.get(code)
        if target and target != code and target in present_set:
            fallback_covered.append({"type": code, "fallback": target})
        else:
            missing_uncovered.append(code)

    validation_files = {
        path.name.removesuffix("_base.png").upper(): validate_png(path, manual_review)
        for path in base_files
    }
    replacement_candidates = sorted(
        code
        for code, result in validation_files.items()
        if result.get("manual_status") == "replacement_required" or not result.get("readable")
    )
    files_with_issues = sorted(
        code for code, result in validation_files.items() if result.get("issues")
    )
    unreadable = sorted(
        code for code, result in validation_files.items() if not result.get("readable")
    )

    mapped_missing_files = sorted(
        code for code, relative_path in mapped_assets.items()
        if not (ROOT / relative_path).is_file()
    )
    unmapped_files = sorted(code for code in present if code not in mapped_assets)
    broken_aliases = sorted(
        {f"{code}->{target}" for code, target in aliases.items() if target not in mapped_assets}
    )

    return {
        "schema_version": 2,
        "generated_at": int(time.time()),
        "bases": {
            "count": len(present),
            "present": present,
            "missing": missing_exact,
            "missing_exact": missing_exact,
            "missing_uncovered": missing_uncovered,
            "fallback_covered": fallback_covered,
            "mapping": {
                "canonical_count": len(mapped_assets),
                "alias_count": len(aliases),
                "mapped_missing_files": mapped_missing_files,
                "unmapped_files": unmapped_files,
                "broken_aliases": broken_aliases,
            },
        },
        "validation": {
            "validator_version": 1,
            "summary": {
                "checked": len(validation_files),
                "unreadable": unreadable,
                "files_with_issues": files_with_issues,
                "replacement_candidates": replacement_candidates,
            },
            "files": validation_files,
        },
        "assets": {
            "liveries": {
                "directory": LIVERY_DIR.relative_to(ROOT).as_posix(),
                "present": listed_pngs(LIVERY_DIR),
                "missing": [],
            },
            "logos": {
                "directory": LOGO_DIR.relative_to(ROOT).as_posix(),
                "present": listed_pngs(LOGO_DIR),
                "missing": [],
            },
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="AEROFOLIO Asset-Inventar und PNG-Validierung")
    parser.add_argument("--check", action="store_true", help="Nur pruefen, Inventar nicht schreiben")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Auch bei bekannten Ersatzkandidaten mit Fehlercode beenden",
    )
    args = parser.parse_args()

    try:
        inventory = build_inventory()
    except RuntimeError as exc:
        print(f"FEHLER: {exc}")
        return 2

    if not args.check:
        INVENTORY_PATH.write_text(
            json.dumps(inventory, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

    bases = inventory["bases"]
    summary = inventory["validation"]["summary"]
    print(
        f"{bases['count']} Bases geprueft; "
        f"{len(bases['missing_exact'])} exakte Typen fehlen "
        f"({len(bases['missing_uncovered'])} ohne Fallback); "
        f"{len(summary['files_with_issues'])} Dateien mit Hinweisen; "
        f"{len(summary['replacement_candidates'])} Ersatzkandidaten."
    )

    hard_failures = bool(
        summary["unreadable"]
        or bases["mapping"]["mapped_missing_files"]
        or bases["mapping"]["broken_aliases"]
    )
    if hard_failures or (args.strict and summary["replacement_candidates"]):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
