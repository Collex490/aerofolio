AEROFOLIO V23.2 – Remote Updater

Neu:
- Update installieren direkt aus AEROFOLIO
- Download über package_url aus latest.json
- SHA-256-Prüfung vor Installation
- Backup unter runtime/backups/
- Rollback bei Installationsfehler
- data/ und runtime/ werden beim Update nicht überschrieben
- Nach erfolgreicher Installation wird die Seite neu geladen

Wichtig:
Der laufende Python-Prozess selbst wird nicht hart beendet. Bei Änderungen an server.py
muss AEROFOLIO/start.bat einmal neu gestartet werden, damit neuer Server-Code aktiv ist.
