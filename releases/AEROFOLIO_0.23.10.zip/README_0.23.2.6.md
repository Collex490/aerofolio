# AEROFOLIO 0.23.2.6

## Cache/Reload-Fix
- `index.html` wird serverseitig mit `Cache-Control: no-store` ausgeliefert.
- API-Antworten werden ebenfalls nicht im Browser-Cache gehalten.
- `app.js` und `styles.css` bleiben über `?v=0.23.2.6` versionsgebunden.
- Nach einem Update wartet der Browser nicht nur auf irgendeinen Server,
  sondern prüft über `/api/update/status`, ob mindestens die neue Version läuft.
- Danach wird ein komplett neuer `index.html`-Request mit einmaligem Zeitstempel geladen.
- Der Zeitstempel wird anschließend wieder aus der Adresszeile entfernt.

## Ziel
Ab diesem Release soll nach „Update installieren“ kein `Strg+F5` mehr notwendig sein.
