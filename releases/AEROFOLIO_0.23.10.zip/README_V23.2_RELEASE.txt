AEROFOLIO V23.2.0 – Release Candidate

Enthält:
- alle Funktionen des zuletzt getesteten V23.2-Stands
- GitHub Versionsprüfung
- Remote-Update-Installer
- SHA-256 Prüfung
- Backup/Rollback
- Sticky Poster
- separate Titel/Standort/Koordinaten-Steuerung
- Missing-Live-Bases
- dynamische Versionsanzeige oben rechts (kein festes V22 mehr)

Vor Veröffentlichung lokal starten und prüfen, dass oben rechts 23.2.0 erscheint.
