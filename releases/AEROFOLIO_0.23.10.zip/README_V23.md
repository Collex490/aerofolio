# AEROFOLIO V23
V23 ergänzt das Asset-Inventar und die sichere Grundlage für Fernupdates.

## Asset-Inventar
`refresh_asset_inventory.bat` erzeugt `data/asset_inventory.json`.
Erfasst werden vorhandene Bases und live erkannte, noch fehlende Flugzeugtypen.
Bereiche für Liveries und Logos sind bereits vorgesehen.

## Fernupdates
`updates/latest.json` ist das Manifest. Fernupdates sind zunächst absichtlich deaktiviert,
bis eine echte HTTPS-Updatequelle samt SHA-256-Prüfung konfiguriert ist.
So wird kein unsicherer allgemeiner Fernzugriff geöffnet.

## Gerät
`runtime/device.json` enthält Gerätename, Version und Update-Kanal.

FlightPortrait bleibt entfernt; die bestehende ADSB.lol-/lokale API-Struktur bleibt erhalten.
