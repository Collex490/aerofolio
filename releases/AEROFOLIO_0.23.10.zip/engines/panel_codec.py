"""AEROFOLIO Spectra 6 panel encoder.

Panel format implementation for 1200x1600 Spectra 6 displays:
- 1200 x 1600 portrait
- 2 pixels per byte, left pixel in high nibble
- exactly 960,000 bytes
- valid codes: 0 black, 1 white, 2 yellow, 3 red, 5 blue, 6 green
"""
from __future__ import annotations

import hashlib

WIDTH = 1200
HEIGHT = 1600
RGBA_BYTES = WIDTH * HEIGHT * 4
PANEL_BYTES = WIDTH * HEIGHT // 2

# RGB approximations used only for nearest-colour quantization.
PALETTE = (
    (0x0, (0, 0, 0)),        # black
    (0x1, (255, 255, 255)),  # white
    (0x2, (245, 205, 0)),    # yellow
    (0x3, (210, 30, 35)),    # red
    (0x5, (35, 80, 160)),    # blue
    (0x6, (45, 145, 75)),    # green
)

def nearest_code(r: int, g: int, b: int) -> int:
    best_code = 1
    best_dist = 1 << 62
    for code, (pr, pg, pb) in PALETTE:
        dr = r - pr
        dg = g - pg
        db = b - pb
        dist = dr*dr + dg*dg + db*db
        if dist < best_dist:
            best_dist = dist
            best_code = code
    return best_code

def rgba_to_panel_bin(rgba: bytes) -> bytes:
    if len(rgba) != RGBA_BYTES:
        raise ValueError(f"expected {RGBA_BYTES} RGBA bytes, got {len(rgba)}")

    src = memoryview(rgba)
    out = bytearray(PANEL_BYTES)
    oi = 0
    for px in range(0, WIDTH * HEIGHT, 2):
        a = px * 4
        b = a + 4
        left = nearest_code(src[a], src[a+1], src[a+2])
        right = nearest_code(src[b], src[b+1], src[b+2])
        out[oi] = (left << 4) | right
        oi += 1
    return bytes(out)

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
