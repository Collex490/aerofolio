AEROFOLIO V23.2.2 – Remote-Update-Test

WICHTIG:
Diese ZIP NICHT manuell als AEROFOLIO-Ordner verwenden.

Sie ist ausschließlich dafür gedacht, als GitHub-Release veröffentlicht
und anschließend von der laufenden V23.2.1 über „Update installieren“
eingespielt zu werden.

Erkennungsmerkmal nach erfolgreichem Update:
Remote Update erfolgreich · 23.2.2
