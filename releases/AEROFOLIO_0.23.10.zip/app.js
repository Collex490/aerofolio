
window.addEventListener("error", (event) => {
  console.error("AEROFOLIO JavaScript error:", event.error || event.message);
  const existing = document.getElementById("jsErrorBanner");
  if (existing) return;
  const banner = document.createElement("div");
  banner.id = "jsErrorBanner";
  banner.style.cssText = [
    "position:fixed","left:20px","right:20px","bottom:20px","z-index:99999",
    "background:#8f2020","color:white","padding:12px 16px","border-radius:10px",
    "font:600 13px system-ui","box-shadow:0 8px 30px rgba(0,0,0,.25)"
  ].join(";");
  banner.textContent = "AEROFOLIO Fehler: " + (event.message || "Unbekannter JavaScript-Fehler");
  document.body.appendChild(banner);
});


const canvas = document.getElementById("portraitCanvas");
if (!canvas) {
  throw new Error("portraitCanvas wurde nicht gefunden");
}
const ctx = canvas.getContext("2d");
if (!ctx) {
  throw new Error("2D-Canvas-Kontext konnte nicht erstellt werden");
}

const demoPlanes = [
  {id:"EK46", airline:"Emirates", type:"Airbus A380-800", icaoType:"A388", reg:"A6-EVS", altitude:"10.620 m", route:"DXB → FRA", accent:"#f4eee1"},
  {id:"SQ325", airline:"Singapore Airlines", type:"Boeing 777-300ER", icaoType:"B77W", reg:"9V-SWV", altitude:"10.970 m", route:"SIN → FRA", accent:"#f0d089"},
  {id:"LH441", airline:"Lufthansa", type:"Airbus A350-900", icaoType:"A359", reg:"D-AIXN", altitude:"11.280 m", route:"FRA → IAH", accent:"#f4eee1"},
  {id:"AF1519", airline:"Air France", type:"Airbus A320-200", icaoType:"A320", reg:"F-GKXM", altitude:"9.450 m", route:"CDG → FRA", accent:"#f4eee1"},
  {id:"UPS202", airline:"UPS Airlines", type:"Boeing 767-300F", icaoType:"B763", reg:"N347UP", altitude:"9.140 m", route:"CGN → EMA", accent:"#f0d089"},
  {id:"CLX610", airline:"Cargolux", type:"Boeing 747-8F", icaoType:"B748", reg:"LX-VCC", altitude:"10.360 m", route:"LUX → HKG", accent:"#f4eee1"}
];
let planes = [...demoPlanes];

const LOCAL_API = "/api/live";
const AEROFOLIO_VERSION = "0.23.10";

function escapeHtml(value){
  return String(value ?? "").replace(/[&<>"']/g,ch=>({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  })[ch]);
}

const styles = [{id:"vintage", name:"Vintage Poster", desc:"Standard"}];

const state = {
  selected: ["EK46","SQ325","LH441"],
  style: "vintage",
  artScale: 1,
  artOffsetX: 0,
  artOffsetY: 0,
  planeLayouts: {},
  ditherMode: "noise",
  ditherStrength: 0.24,
  showAirlineOnAircraft: true,
  location: "Idstein-Wörsdorf",
  lat: "50.223",
  lon: "8.229",
  radius: 25,
  bgColor: "#b72618",
  textColor: "#f4eee1",
  font: "Georgia",
  texts: {
    eyebrow:{label:"Kopfzeile", value:"AEROFOLIO", visible:true},
    title:{label:"Titel", value:"DER HIMMEL ÜBER", visible:true, x:0, y:0, size:38},
    location:{label:"Standorttext", value:"IDSTEIN-WÖRSDORF", visible:true, x:0, y:0, size:58},
    coords:{label:"Koordinaten", value:"50.223° N   8.229° E", visible:true, x:0, y:0, size:24},
    date:{label:"Datum", value:new Date().toLocaleDateString("de-DE",{day:"2-digit",month:"short",year:"numeric"}).toUpperCase(), visible:true},
    quote:{label:"Zitat", value:"ÜBER DEN WOLKEN MUSS DIE FREIHEIT WOHL GRENZENLOS SEIN.", visible:true},
    author:{label:"Autor", value:"REINHARD MEY", visible:true}
  }
};





// V17: no procedural aircraft drawings.
// Aircraft artwork must come from the local PNG/WebP image library.

const vintageProfileCache=new Map();

function clamp(value,min,max){
  return Math.min(max,Math.max(min,value));
}

function vintageProfileUrl(plane){
  const type=encodeURIComponent((plane?.icaoType || plane?.type || "").toUpperCase());
  return `/api/vintage-profile?type=${type}`;
}

function loadVintageProfile(plane){
  const key=`${plane?.icaoType || plane?.type || ""}`;
  if(vintageProfileCache.has(key)) return vintageProfileCache.get(key);
  const promise=new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>resolve(img);
    img.onerror=()=>reject(new Error("curated vintage profile missing"));
    img.src=vintageProfileUrl(plane);
  });
  vintageProfileCache.set(key,promise);
  return promise;
}

async function drawVintageProfile(plane,cx,cy,maxW,maxH){
  const requestedPlane = state.showAirlineOnAircraft
    ? plane
    : {...plane, airline:"", operator:""};

  try{
    const img=await loadVintageProfile(requestedPlane);
    maxW=Math.min(maxW,1040);
    maxH=Math.min(maxH,230);
    const scale=Math.min(maxW/(img.naturalWidth||img.width),maxH/(img.naturalHeight||img.height));
    const w=(img.naturalWidth||img.width)*scale;
    const h=(img.naturalHeight||img.height)*scale;
    const safeCx=clamp(cx,72+w/2,1128-w/2);
    const safeCy=clamp(cy,150+h/2,1135-h/2);
    const left=safeCx-w/2;
    const top=safeCy-h/2;
    ctx.drawImage(img,left,top,w,h);

    // Return the rendered rectangle so labels can be anchored to the
    // actual aircraft position and size. This keeps the information block
    // attached when a plane is moved or scaled.
    return {left, top, right:left+w, bottom:top+h, width:w, height:h, cx:safeCx, cy:safeCy};
  }catch(err){
    return null;
  }
}

function setProviderStatus(provider, kind, text){
  const id = provider === "fp" ? "fpProviderStatus" : "adsbProviderStatus";
  const el = document.getElementById(id);
  if(!el) return;
  el.className = "";
  if(kind) el.classList.add(`provider-${kind}`);
  el.textContent = text;
}

function setActiveProvider(text){
  const el = document.getElementById("activeProvider");
  if(el) el.textContent = text || "–";
}

function setLiveStatus(kind, title, info){
  const dot=document.getElementById("liveDot");
  dot.className="live-dot"+(kind?` ${kind}`:"");
  document.getElementById("liveStatus").textContent=title;
  document.getElementById("liveInfo").textContent=info;
}

function cleanCallsign(value){
  return (value || "").trim().replace(/\s+/g,"");
}

function feetToMeters(ft){
  const n=Number(ft);
  if(!Number.isFinite(n)) return "–";
  return `${(Math.round((n * 0.3048) / 10) * 10).toLocaleString("de-DE")} m`;
}

function altitudeLabel(ac){
  let alt=ac.alt_baro ?? ac.alt_geom;
  if(alt==="ground") return "Boden";
  const n=Number(alt);
  if(!Number.isFinite(n)) return "–";
  return `${Math.round(n*0.3048).toLocaleString("de-DE")} m`;
}

function distanceKm(lat1,lon1,lat2,lon2){
  const r=6371;
  const dLat=(lat2-lat1)*Math.PI/180;
  const dLon=(lon2-lon1)*Math.PI/180;
  const a=Math.sin(dLat/2)**2+
    Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return 2*r*Math.asin(Math.sqrt(a));
}

function updateQueryCoordinates(){
  const el=document.getElementById("queryCoordinates");
  if(!el) return;
  const lat=Number(state.lat);
  const lon=Number(state.lon);
  if(Number.isFinite(lat) && Number.isFinite(lon)){
    el.textContent=`${lat.toFixed(4)}, ${lon.toFixed(4)}`;
  }else{
    el.textContent="–";
  }
}

async function fetchLocalLive(lat, lon, radiusKm){
  const url=`${LOCAL_API}?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&radius_km=${encodeURIComponent(radiusKm)}`;
  const response=await fetch(url,{headers:{"Accept":"application/json"}});
  if(!response.ok){
    let detail="";
    try{
      const body=await response.json();
      detail=body?.error ? `: ${body.error}` : "";
    }catch{}
    throw new Error(`HTTP ${response.status}${detail}`);
  }
  return response.json();
}

function backendAircraftToPlane(ac){
  return {
    id:cleanCallsign(ac.callsign) || (ac.hex || "UNKNOWN").toUpperCase(),
    hex:(ac.hex || "").toLowerCase(),
    airline:ac.operator || "Betreiber unbekannt",
    type:ac.type || "Flugzeug",
    icaoType:ac.type || "",
    family:ac.family || "generic",
    reg:ac.registration || (ac.hex || "").toUpperCase(),
    altitude:ac.altitude_m == null ? "–" : `${Math.round(ac.altitude_m).toLocaleString("de-DE")} m`,
    route:ac.route || "Route unbekannt",
    lat:Number(ac.lat),
    lon:Number(ac.lon),
    distance:Number(ac.distance_km),
    source:ac.source || "merged",
    sources:Array.isArray(ac.sources) ? ac.sources : [ac.source || "merged"],
    accent:"#f4eee1"
  };
}

async function loadLiveAircraft(){
  setLiveStatus("loading","Live-Abfrage gestartet","ADSB.lol wird abgefragt …");

  const lat=Number(state.lat), lon=Number(state.lon);
  const radiusKm=Number(state.radius);
  if(!Number.isFinite(lat) || !Number.isFinite(lon)){
    setLiveStatus("error","Standort ungültig","Bitte Koordinaten prüfen.");
    return;
  }

  updateQueryCoordinates();
  setActiveProvider("ADSB.lol");
  setProviderStatus("adsb","loading","Wird abgefragt …");

  try{
    const data=await fetchLocalLive(lat,lon,radiusKm);
    const adsb=data.providers?.adsb_lol || {};
    if(adsb.ok){
      setProviderStatus("adsb",adsb.count>0?"ok":"empty",adsb.count>0?`${adsb.count} Flugzeuge`:"Keine Treffer");
    }else{
      setProviderStatus("adsb","error",adsb.error || "Fehler");
    }
    planes=(data.aircraft || []).map(backendAircraftToPlane);
    if(planes.length){
      state.selected=planes.slice(0,Math.min(3,planes.length)).map(p=>p.id);
      renderPlaneList(); safeRenderPortrait();
      setLiveStatus("ok","Live-Daten geladen",`${planes.length} Flugzeuge · ${new Date().toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"})}`);
    }else{
      state.selected=[]; renderPlaneList(); safeRenderPortrait();
      setLiveStatus("ok","Keine Live-Flugzeuge gefunden","Im gewählten Radius wurden aktuell keine ADS-B-Positionsdaten gefunden.");
    }
  }catch(err){
    console.error(err);
    setProviderStatus("adsb","error","Backend nicht erreichbar");
    setLiveStatus("error","Live-Abruf fehlgeschlagen",`${err.message}. Läuft die App über start.bat?`);
  }
}

function useDemoData(){
  planes=[...demoPlanes];
  state.selected=["EK46","SQ325","LH441"].filter(id=>planes.some(p=>p.id===id));
  renderPlaneList(); safeRenderPortrait();
  setProviderStatus("adsb","","Nicht geprüft"); setActiveProvider("ADSB.lol");
  setLiveStatus("","Testdaten aktiv","Kein Live-Abruf.");
}



let renderQueued=false;
let renderRunning=false;
let renderWaiters=[];

function nextAnimationFrame(){
  return new Promise(resolve=>requestAnimationFrame(resolve));
}

function settleRenderWaiters(error=null){
  const waiters=renderWaiters;
  renderWaiters=[];
  waiters.forEach(({resolve,reject})=>error ? reject(error) : resolve());
}

async function drainRenderQueue(){
  if(renderRunning) return;
  renderRunning=true;
  let failure=null;
  try{
    while(renderQueued){
      renderQueued=false;
      await renderPortrait();
      if(renderQueued) await nextAnimationFrame();
    }
  }catch(err){
    failure=err;
    console.error("AEROFOLIO render error:",err);
    window.dispatchEvent(new ErrorEvent("error",{
      message:err?.message || "Poster konnte nicht gerendert werden",
      error:err
    }));
  }finally{
    renderRunning=false;
    if(renderQueued){
      requestAnimationFrame(drainRenderQueue);
    }else{
      settleRenderWaiters(failure);
    }
  }
}

function safeRenderPortrait(){
  renderQueued=true;
  const pending=new Promise((resolve,reject)=>renderWaiters.push({resolve,reject}));
  if(!renderRunning) requestAnimationFrame(drainRenderQueue);
  return pending;
}

function renderPlaneList(){
  const list = document.getElementById("planeList");
  list.innerHTML = "";
  planes.forEach(p=>{
    const card=document.createElement("label");
    const checked=state.selected.includes(p.id);
    card.className="plane-card"+(checked?" selected":"");
    const safeId=escapeHtml(p.id);
    const safeAirline=escapeHtml(p.airline);
    const safeType=escapeHtml(p.type);
    const safeAltitude=escapeHtml(p.altitude);
    const safeRegistration=escapeHtml(p.reg);
    card.innerHTML=`
      <div class="plane-icon">✈</div>
      <div class="plane-main">
        <strong>${safeId}</strong>
        <small>${safeAirline}<br>${safeType}</small>
        <span class="source-tag">${p.source==="adsb.lol" ? "ADSB.LOL" : "DEMO"}</span>
      </div>
      <div class="plane-meta">${safeAltitude}<br>${safeRegistration}${Number.isFinite(p.distance)?`<br>${p.distance.toFixed(1)} km`:``}</div>
      <input type="checkbox" ${checked?"checked":""} style="grid-column:1/-1;justify-self:end">
    `;
    const cb=card.querySelector("input");
    cb.addEventListener("change",()=>{
      if(cb.checked){
        if(state.selected.length>=4){ cb.checked=false; alert("Maximal 4 Flugzeuge pro Poster."); return; }
        state.selected.push(p.id);
      } else {
        state.selected=state.selected.filter(id=>id!==p.id);
      }
      renderPlaneList(); safeRenderPortrait();
    });
    list.appendChild(card);
  });
  document.getElementById("selectedCount").textContent=`${state.selected.length}/4`;
  renderPlaneLayoutControls();
}

function renderStyles(){ state.style="vintage"; }



function getPlaneLayout(id, index=0, count=1){
  if(!state.planeLayouts[id]){
    const defaultGap=count===2 ? 350 : count===3 ? 275 : count>=4 ? 225 : 0;
    state.planeLayouts[id]={x:0,y:0,scale:1,textPos:"tail",textX:0,textY:0,textGap:18,gap:defaultGap || 225};
  }
  return state.planeLayouts[id];
}

function renderPlaneLayoutControls(){
  const box=document.getElementById("planeLayoutControls");
  if(!box) return;
  box.innerHTML="";
  const selectedPlanes=state.selected.map(id=>planes.find(p=>p.id===id)).filter(Boolean);
  if(!selectedPlanes.length){
    box.innerHTML='<p class="muted">Wähle zuerst ein Flugzeug aus.</p>';
    return;
  }

  selectedPlanes.forEach((p,index)=>{
    const layout=getPlaneLayout(p.id,index,selectedPlanes.length);
    const card=document.createElement("div");
    card.className="plane-layout-card";
    card.innerHTML=`
      <div class="plane-layout-head">
        <strong>${escapeHtml(p.id)}</strong>
        <small>${escapeHtml(p.icaoType || p.type || "Flugzeug")}</small>
      </div>
      <label class="plane-layout-field">
        <span>Links / rechts <b data-val="x">${layout.x}</b></span>
        <input data-key="x" type="range" min="-220" max="220" step="5" value="${layout.x}">
      </label>
      <label class="plane-layout-field">
        <span>Hoch / runter <b data-val="y">${layout.y}</b></span>
        <input data-key="y" type="range" min="-80" max="80" step="5" value="${layout.y}">
      </label>
      <label class="plane-layout-field">
        <span>Größe <b data-val="scale">${Math.round(layout.scale*100)}%</b></span>
        <input data-key="scale" type="range" min="70" max="125" step="2" value="${Math.round(layout.scale*100)}">
      </label>
      <label class="plane-layout-field select-field">
        <span>Info-Text · am Flugzeug angepinnt</span>
        <select data-key="textPos">
          <option value="tail" ${layout.textPos==="tail"?"selected":""}>am Heck</option>
          <option value="nose" ${layout.textPos==="nose"?"selected":""}>an der Nase</option>
          <option value="below" ${layout.textPos==="below"?"selected":""}>unter dem Flugzeug</option>
          <option value="off" ${layout.textPos==="off"?"selected":""}>ausblenden</option>
        </select>
      </label>
      <label class="plane-layout-field">
        <span>Text-Abstand <b data-val="textGap">${layout.textGap ?? 18}px</b></span>
        <input data-key="textGap" type="range" min="4" max="80" step="2" value="${layout.textGap ?? 18}">
      </label>
      <label class="plane-layout-field">
        <span>Text links / rechts <b data-val="textX">${layout.textX || 0}</b></span>
        <input data-key="textX" type="range" min="-180" max="180" step="5" value="${layout.textX || 0}">
      </label>
      <label class="plane-layout-field">
        <span>Text hoch / runter <b data-val="textY">${layout.textY || 0}</b></span>
        <input data-key="textY" type="range" min="-100" max="120" step="5" value="${layout.textY || 0}">
      </label>
      <label class="plane-layout-field">
        <span>Abstand danach <b data-val="gap">${layout.gap}px</b></span>
        <input data-key="gap" type="range" min="140" max="300" step="5" value="${layout.gap}">
      </label>
    `;

    card.querySelectorAll('input[type="range"]').forEach(input=>{
      input.addEventListener("input",()=>{
        const key=input.dataset.key;
        const v=Number(input.value);
        if(key==="scale") layout.scale=v/100;
        else layout[key]=v;
        const out=card.querySelector(`[data-val="${key}"]`);
        if(out) out.textContent=key==="scale" ? `${v}%` : (key==="gap" || key==="textGap") ? `${v}px` : `${v}`;
        safeRenderPortrait();
      });
    });
    card.querySelector('select[data-key="textPos"]').addEventListener("change",e=>{
      layout.textPos=e.target.value;
      safeRenderPortrait();
    });
    box.appendChild(card);
  });
}

function drawPlaneInfo(p, bounds, layout, fg){
  const pos=layout.textPos || "tail";
  if(pos==="off" || !bounds) return;

  const textGap=Number.isFinite(layout.textGap) ? layout.textGap : 18;
  const textX=layout.textX || 0;
  const textY=layout.textY || 0;
  let x=bounds.left, align="left", baseY=bounds.bottom + textGap;

  // The anchor is derived from the rendered aircraft rectangle, not from
  // the row position. Therefore translation and scaling of the aircraft
  // automatically move the label with it. Fine offsets remain available.
  if(pos==="nose"){
    x=bounds.right; align="right";
  }else if(pos==="below"){
    x=bounds.cx; align="center";
  }

  x=clamp(x+textX,88,1112);
  baseY=clamp(baseY+textY,175,1170);

  if(state.showAirlineOnAircraft && p.airline){
    drawFittedText(p.airline,x,baseY,18,700,align,fg,520,12);
    baseY+=25;
  }
  drawFittedText(`${p.id} · ${p.type || "Typ unbekannt"} · ${p.reg || "–"}`,x,baseY,15,500,align,fg,520,10);
  drawFittedText(`${p.altitude} · ${p.route || "Route unbekannt"}`,x,baseY+22,14,500,align,fg,520,10);
}

function renderTextControls(){
  const box=document.getElementById("textControls");
  box.innerHTML="";
  const movableKeys=new Set(["title","location","coords"]);

  Object.entries(state.texts).forEach(([key,obj])=>{
    const yLimits={title:[-60,80],location:[-90,70],coords:[-100,50]}[key] || [-100,100];
    const row=document.createElement("div");
    row.className="text-row";
    row.innerHTML=`
      <div class="text-row-top">
        <strong>${escapeHtml(obj.label)}</strong>
        <label><input type="checkbox" ${obj.visible?"checked":""}> anzeigen</label>
      </div>
      ${key==="quote" ? `<textarea>${escapeHtml(obj.value)}</textarea>` : `<input type="text" value="${escapeHtml(obj.value)}">`}
      ${movableKeys.has(key) ? `
        <div class="title-layout-controls">
          <label class="plane-layout-field">
            <span>Links / rechts <b data-text-val="x">${obj.x || 0}</b></span>
            <input data-text-key="x" type="range" min="-180" max="180" step="5" value="${obj.x || 0}">
          </label>
          <label class="plane-layout-field">
            <span>Hoch / runter <b data-text-val="y">${obj.y || 0}</b></span>
            <input data-text-key="y" type="range" min="${yLimits[0]}" max="${yLimits[1]}" step="5" value="${obj.y || 0}">
          </label>
          <label class="plane-layout-field">
            <span>Größe <b data-text-val="size">${obj.size || (key==="location"?58:key==="title"?38:24)}px</b></span>
            <input data-text-key="size" type="range"
              min="${key==="location"?24:key==="title"?18:12}"
              max="${key==="location"?90:key==="title"?70:48}"
              step="1"
              value="${obj.size || (key==="location"?58:key==="title"?38:24)}">
          </label>
          <button type="button" class="ghost mini title-reset-btn">Position zurücksetzen</button>
        </div>
      ` : ""}
    `;

    const toggle=row.querySelector('input[type="checkbox"]');
    const input=row.querySelector(key==="quote"?"textarea":'input[type="text"]');
    toggle.addEventListener("change",()=>{obj.visible=toggle.checked;safeRenderPortrait();});
    input.addEventListener("input",()=>{obj.value=input.value;safeRenderPortrait();});

    if(movableKeys.has(key)){
      row.querySelectorAll('input[data-text-key]').forEach(slider=>{
        slider.addEventListener("input",()=>{
          const prop=slider.dataset.textKey;
          const value=Number(slider.value);
          obj[prop]=value;
          const out=row.querySelector(`[data-text-val="${prop}"]`);
          if(out) out.textContent=prop==="size" ? `${value}px` : `${value}`;
          safeRenderPortrait();
        });
      });

      const reset=row.querySelector(".title-reset-btn");
      reset.addEventListener("click",()=>{
        const defaults={
          title:{x:0,y:0,size:38},
          location:{x:0,y:0,size:58},
          coords:{x:0,y:0,size:24}
        }[key];
        Object.assign(obj,defaults);
        row.querySelector('input[data-text-key="x"]').value=defaults.x;
        row.querySelector('input[data-text-key="y"]').value=defaults.y;
        row.querySelector('input[data-text-key="size"]').value=defaults.size;
        row.querySelector('[data-text-val="x"]').textContent=defaults.x;
        row.querySelector('[data-text-val="y"]').textContent=defaults.y;
        row.querySelector('[data-text-val="size"]').textContent=`${defaults.size}px`;
        safeRenderPortrait();
      });
    }

    box.appendChild(row);
  });
}

function drawText(text,x,y,size,weight=400,align="center",color=state.textColor,font=state.font){
  ctx.fillStyle=color;
  ctx.textAlign=align;
  ctx.textBaseline="alphabetic";
  ctx.font=`${weight} ${size}px "${font}"`;
  ctx.fillText(text,x,y);
}

function drawFittedText(text,x,y,size,weight,align,color,maxWidth,minSize=12){
  const value=String(text ?? "");
  const availableWidth=align==="center"
    ? Math.max(80,2*Math.min(x-70,1130-x))
    : align==="right" ? Math.max(80,x-70) : Math.max(80,1130-x);
  maxWidth=Math.min(maxWidth,availableWidth);
  let fittedSize=size;
  ctx.font=`${weight} ${fittedSize}px "${state.font}"`;
  while(fittedSize>minSize && ctx.measureText(value).width>maxWidth){
    fittedSize-=1;
    ctx.font=`${weight} ${fittedSize}px "${state.font}"`;
  }
  drawText(value,x,y,fittedSize,weight,align,color);
}

function drawPlaneSilhouette(x,y,w,p,color,technical=false){
  ctx.save();
  ctx.translate(x,y);
  const s=w/500;
  ctx.scale(s,s);
  ctx.strokeStyle=color; ctx.fillStyle=color; ctx.lineWidth=technical?4:2;

  const family=(p?.family || "generic").toLowerCase();
  const poly=(pts)=>{
    ctx.beginPath();
    ctx.moveTo(pts[0][0],pts[0][1]);
    for(let i=1;i<pts.length;i++) ctx.lineTo(pts[i][0],pts[i][1]);
    ctx.closePath();
    technical ? ctx.stroke() : ctx.fill();
  };

  if(family==="helicopter"){
    ctx.beginPath();ctx.ellipse(245,120,95,48,0,0,Math.PI*2);technical?ctx.stroke():ctx.fill();
    poly([[35,115],[165,105],[165,130],[35,130],[12,145],[12,96]]);
    ctx.fillRect(235,25,10,55);ctx.fillRect(105,20,280,8);
  }else if(family==="ga"){
    poly([[15,120],[120,102],[210,98],[272,35],[310,35],[286,98],[410,105],[478,120],[408,135],[286,140],[310,205],[272,205],[210,140],[110,138]]);
  }else if(family==="atr"){
    poly([[10,120],[125,101],[212,96],[266,42],[298,42],[282,96],[410,105],[480,120],[410,136],[282,142],[298,198],[266,198],[212,142],[115,139]]);
    ctx.beginPath();ctx.arc(190,111,27,0,Math.PI*2);technical?ctx.stroke():ctx.fill();
    ctx.beginPath();ctx.arc(338,112,27,0,Math.PI*2);technical?ctx.stroke():ctx.fill();
  }else if(family==="a380" || family==="b747"){
    poly([[8,120],[105,98],[205,94],[270,20],[312,20],[287,94],[402,102],[486,120],[402,140],[287,146],[315,220],[270,220],[205,146],[95,142]]);
    if(!technical) ctx.fillRect(65,105,350,30);
  }else if(["a330","a350","b767","b777","b787"].includes(family)){
    poly([[8,120],[120,98],[208,92],[278,15],[320,15],[290,92],[414,103],[490,120],[414,139],[290,146],[322,225],[276,225],[208,146],[108,141]]);
  }else if(["ejet","crj"].includes(family)){
    poly([[12,120],[135,102],[218,98],[270,48],[304,48],[287,98],[410,106],[480,120],[410,135],[287,140],[305,194],[270,194],[218,140],[125,138]]);
  }else{
    poly([[10,120],[130,101],[218,96],[272,36],[310,36],[287,96],[414,105],[486,120],[414,137],[287,142],[312,205],[270,205],[218,142],[118,139]]);
  }

  if(technical){
    ctx.setLineDash([10,8]);
    ctx.beginPath();ctx.moveTo(30,120);ctx.lineTo(465,120);ctx.stroke();
    ctx.setLineDash([]);
  }
  ctx.restore();
}

function backgroundForStyle(){
  if(state.style==="blueprint") return "#23486a";
  if(state.style==="handdrawn" || state.style==="exploded" || state.style==="cutaway") return "#eee7d8";
  return state.bgColor;
}
function colorForStyle(){
  if(state.style==="blueprint") return "#e8f0f4";
  if(state.style==="handdrawn" || state.style==="exploded" || state.style==="cutaway") return "#272522";
  return state.textColor;
}

async function renderPortrait(){
  const bg=state.bgColor;
  const fg=state.textColor;

  ctx.fillStyle=bg;
  ctx.fillRect(0,0,1200,1600);

  ctx.strokeStyle=fg;
  ctx.globalAlpha=.62;
  ctx.lineWidth=3;
  ctx.strokeRect(46,46,1108,1508);
  ctx.globalAlpha=1;

  if(state.texts.eyebrow.visible) drawText(state.texts.eyebrow.value,88,105,26,700,"left",fg);
  if(state.texts.date.visible) drawText(state.texts.date.value,1112,105,22,600,"right",fg);

  const planesToDraw=state.selected.map(id=>planes.find(p=>p.id===id)).filter(Boolean);
  const count=planesToDraw.length;

  const startY=count<=1 ? 360 : count===2 ? 300 : count===3 ? 235 : 205;
  let yCursor=startY;

  for(let i=0;i<count;i++){
    const p=planesToDraw[i];
    const layout=getPlaneLayout(p.id,i,count);
    const y=yCursor + (layout.y || 0);

    const offsetX=(state.artOffsetX || 0) + (layout.x || 0);
    const offsetY=state.artOffsetY || 0;
    const scale=(state.artScale || 1) * (layout.scale || 1);

    let bounds=await drawVintageProfile(
      p,
      600+offsetX,
      y+offsetY,
      820*scale,
      200*scale
    );

    if(!bounds){
      const fallbackW=Math.min(1040,540*scale);
      const fallbackH=Math.min(230,116*scale);
      const fallbackCx=clamp(600+offsetX,72+fallbackW/2,1128-fallbackW/2);
      const fallbackCy=clamp(y+offsetY,150+fallbackH/2,1135-fallbackH/2);
      bounds={
        left:fallbackCx-fallbackW/2, top:fallbackCy-fallbackH/2,
        right:fallbackCx+fallbackW/2, bottom:fallbackCy+fallbackH/2,
        width:fallbackW, height:fallbackH, cx:fallbackCx, cy:fallbackCy
      };
      ctx.strokeStyle=fg;
      ctx.globalAlpha=.38;
      ctx.lineWidth=2;
      ctx.strokeRect(bounds.left,bounds.top,bounds.width,bounds.height);
      ctx.globalAlpha=1;
      drawText("BILD NOCH NICHT IN DER BIBLIOTHEK",bounds.cx,bounds.cy-4,17,700,"center",fg);
      drawText(`${p.airline || "Unbekannte Airline"} · ${p.icaoType || p.type || "Typ unbekannt"}`,bounds.cx,bounds.cy+27,15,500,"center",fg);
    }

    drawPlaneInfo(p,bounds,layout,fg);
    yCursor += (layout.gap || 225);
  }

  const footerY=1240;
  const titleText=state.texts.title;
  const locationText=state.texts.location;
  const coordsText=state.texts.coords;

  if(titleText.visible) drawFittedText(
    titleText.value,
    600+(titleText.x || 0),
    footerY+(titleText.y || 0),
    titleText.size || 38,
    600,"center",fg,1020,18
  );

  if(locationText.visible) drawFittedText(
    locationText.value,
    600+(locationText.x || 0),
    footerY+78+(locationText.y || 0),
    locationText.size || 58,
    700,"center",fg,1020,24
  );

  if(coordsText.visible) drawFittedText(
    coordsText.value,
    600+(coordsText.x || 0),
    footerY+130+(coordsText.y || 0),
    coordsText.size || 24,
    500,"center",fg,1020,12
  );

  if(state.texts.quote.visible){
    const q=state.texts.quote.value;
    const words=q.split(" "); let line="", lines=[];
    words.forEach(word=>{
      const test=line+word+" ";
      ctx.font=`500 22px "${state.font}"`;
      if(ctx.measureText(test).width>760 && line){
        lines.push(line.trim());
        line=word+" ";
      }else{
        line=test;
      }
    });
    if(line) lines.push(line.trim());
    const visibleLines=lines.slice(0,3);
    if(lines.length>3 && visibleLines.length){
      visibleLines[2]=visibleLines[2].replace(/[.…]*$/,"")+"…";
    }
    visibleLines.forEach((l,i)=>drawFittedText(l,600,1450+i*30,22,500,"center",fg,760,14));
  }

  if(state.texts.author.visible){
    drawText("– "+state.texts.author.value+" –",600,1540,18,600,"center",fg);
  }

  applyVintagePrintEffect();
}

const PRINT_NOISE=(()=>{
  const values=new Float32Array(16384);
  let seed=0x6d2b79f5;
  for(let i=0;i<values.length;i++){
    seed=(Math.imul(seed^seed>>>15,1|seed)+Math.imul(seed^seed>>>7,61|seed))^seed;
    values[i]=((seed^seed>>>14)>>>0)/4294967296-.5;
  }
  return values;
})();

function applyVintagePrintEffect(){
  const strength=Math.max(0,Math.min(1,state.ditherStrength || 0));
  if(state.ditherMode==="flat" || strength<=0) return;

  const image=ctx.getImageData(0,0,1200,1600);
  const d=image.data;

  // Subtle poster-print texture. We keep it intentionally mild because the
  // final E-Ink conversion will quantize the palette again.
  const bayer=[
    [0,8,2,10],
    [12,4,14,6],
    [3,11,1,9],
    [15,7,13,5]
  ];

  for(let y=0;y<1600;y++){
    for(let x=0;x<1200;x++){
      const idx=(y*1200+x)*4;

      let delta=0;
      if(state.ditherMode==="bayer"){
        const v=bayer[y%4][x%4]/15 - .5;
        delta=v*18*strength;
      }else{
        // Deterministic grain; the lookup table avoids millions of sine calls per redraw.
        delta=PRINT_NOISE[(y*1200+x)&(PRINT_NOISE.length-1)]*15*strength;
      }

      d[idx]=Math.max(0,Math.min(255,d[idx]+delta));
      d[idx+1]=Math.max(0,Math.min(255,d[idx+1]+delta));
      d[idx+2]=Math.max(0,Math.min(255,d[idx+2]+delta));
    }
  }
  ctx.putImageData(image,0,0);
}

document.getElementById("bgColor").addEventListener("input",e=>{state.bgColor=e.target.value;safeRenderPortrait();});
document.getElementById("textColor").addEventListener("input",e=>{state.textColor=e.target.value;safeRenderPortrait();});
document.getElementById("fontSelect").addEventListener("change",e=>{state.font=e.target.value;safeRenderPortrait();});

function renderLibraryStatus(assets){
  const el=document.getElementById("libraryTypeStatus");
  if(!el) return;
  const groups=[
    ["Airbus",["A20N","A21N","A318","A319","A320","A321","A332","A333","A339","A343","A346","A359","A35K","A388"]],
    ["Boeing",["B38M","B39M","B737","B738","B739","B744","B752","B763","B772","B77W","B788","B789"]],
    ["Regional",["CRJ9","DHC8","E190","E195"]]
  ];
  el.innerHTML=groups.map(([name,types])=>{
    const chips=types.map(t=>`<span class="type-status ${assets[t]?"ok":"missing"}">${t} ${assets[t]?"✓":"×"}</span>`).join("");
    return `<div class="type-status-group"><strong>${name}</strong><div>${chips}</div></div>`;
  }).join("");
}

async function refreshLibraryStatus(){
  try{
    const r=await fetch("/api/library/status");
    if(!r.ok) return;
    const data=await r.json();
    renderLibraryStatus(data.assets||{});
    const status=document.getElementById("libraryBuildStatus");
    if(status && data.available_count){
      status.className="panel-export-status ok";
      status.textContent=`Bibliothek: ${data.available_count}/${data.total_count} Kern-Typen vorhanden.`;
    }
  }catch(err){}
}
document.getElementById("artScale")?.addEventListener("input",e=>{state.artScale=Number(e.target.value)/100;safeRenderPortrait();});
document.getElementById("artOffsetX")?.addEventListener("input",e=>{state.artOffsetX=Number(e.target.value);safeRenderPortrait();});
document.getElementById("artOffsetY")?.addEventListener("input",e=>{state.artOffsetY=Number(e.target.value);safeRenderPortrait();});
document.getElementById("ditherMode")?.addEventListener("change",e=>{state.ditherMode=e.target.value;safeRenderPortrait();});
document.getElementById("ditherStrength")?.addEventListener("input",e=>{state.ditherStrength=Number(e.target.value)/100;safeRenderPortrait();});
document.getElementById("showAirlineOnAircraft")?.addEventListener("change",e=>{
  state.showAirlineOnAircraft=!!e.target.checked;
  safeRenderPortrait();
});
document.getElementById("refreshLiveBtn").addEventListener("click", async (event) => {
  event.preventDefault();
  event.stopPropagation();

  const button = document.getElementById("refreshLiveBtn");
  const oldText = button.textContent;

  try {
    button.disabled = true;
    button.textContent = "Lade Live-Flugzeuge …";
    await loadLiveAircraft();
    await refreshMissingBases();
  } finally {
    button.disabled = false;
    button.textContent = oldText;
  }
});

function setExportStatus(kind,text){
  const status=document.getElementById("panelExportStatus");
  if(!status) return;
  status.className=`panel-export-status${kind?` ${kind}`:""}`;
  status.textContent=text;
}

function downloadHref(href,filename){
  const link=document.createElement("a");
  link.href=href;
  if(filename) link.download=filename;
  link.hidden=true;
  document.body.appendChild(link);
  link.click();
  link.remove();
}

function canvasPngBlob(){
  return new Promise((resolve,reject)=>{
    canvas.toBlob(blob=>blob ? resolve(blob) : reject(new Error("PNG konnte nicht erzeugt werden.")),"image/png");
  });
}

function exportFilename(extension){
  const now=new Date();
  const stamp=[now.getFullYear(),String(now.getMonth()+1).padStart(2,"0"),String(now.getDate()).padStart(2,"0")].join("-");
  return `aerofolio-${stamp}.${extension}`;
}

async function exportPng(){
  const button=document.getElementById("exportBtn");
  if(button) button.disabled=true;
  setExportStatus("","PNG wird vorbereitet …");
  try{
    await safeRenderPortrait();
    const blob=await canvasPngBlob();
    const url=URL.createObjectURL(blob);
    downloadHref(url,exportFilename("png"));
    window.setTimeout(()=>URL.revokeObjectURL(url),1000);
    setExportStatus("ok","PNG wurde zum Speichern bereitgestellt.");
  }catch(err){
    setExportStatus("error",`PNG-Export fehlgeschlagen: ${err.message}`);
  }finally{
    if(button) button.disabled=false;
  }
}

async function exportPanelBinary(){
  const button=document.getElementById("panelExportBtn");
  if(button) button.disabled=true;
  setExportStatus("","E-Ink-Datei wird erzeugt …");
  try{
    const headers=adminHeaders({"Content-Type":"application/octet-stream"});
    await safeRenderPortrait();
    const pixels=ctx.getImageData(0,0,canvas.width,canvas.height).data;
    const body=pixels.buffer.slice(pixels.byteOffset,pixels.byteOffset+pixels.byteLength);
    const response=await fetch("/api/panel/convert",{method:"POST",headers,body});
    const data=await response.json().catch(()=>({}));
    if(!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
    downloadHref(data.download_url || "/api/panel/current.bin",exportFilename("bin"));
    setExportStatus("ok","E-Ink-Datei wurde erzeugt und heruntergeladen.");
  }catch(err){
    setExportStatus("error",`E-Ink-Export fehlgeschlagen: ${err.message}`);
  }finally{
    if(button) button.disabled=false;
  }
}

function setLocationStatus(kind,text){
  const status=document.getElementById("locationSearchStatus");
  if(!status) return;
  status.className=`location-search-status${kind?` ${kind}`:""}`;
  status.textContent=text;
}

function readLocationDraft(){
  const name=(document.getElementById("locationInput")?.value || "").trim();
  const lat=Number(document.getElementById("latInput")?.value);
  const lon=Number(document.getElementById("lonInput")?.value);
  if(!name) throw new Error("Bitte eine Bezeichnung für den Standort eingeben.");
  if(!Number.isFinite(lat) || lat < -90 || lat > 90) throw new Error("Der Breitengrad muss zwischen −90 und 90 liegen.");
  if(!Number.isFinite(lon) || lon < -180 || lon > 180) throw new Error("Der Längengrad muss zwischen −180 und 180 liegen.");
  return {name,lat,lon};
}

function coordinatePosterText(lat,lon){
  const ns=lat>=0?"N":"S";
  const ew=lon>=0?"E":"W";
  return `${Math.abs(lat).toFixed(3)}° ${ns}   ${Math.abs(lon).toFixed(3)}° ${ew}`;
}

function validateLocationDraft(){
  try{
    const draft=readLocationDraft();
    setLocationStatus("ok",`${draft.name}: ${draft.lat.toFixed(4)}, ${draft.lon.toFixed(4)}`);
    return draft;
  }catch(err){
    setLocationStatus("error",err.message);
    return null;
  }
}

function openLocationDialog(){
  const dialog=document.getElementById("locationDialog");
  document.getElementById("locationInput").value=state.location;
  document.getElementById("latInput").value=state.lat;
  document.getElementById("lonInput").value=state.lon;
  setLocationStatus("","Noch nicht geprüft");
  if(dialog?.showModal) dialog.showModal();
}

function saveLocation(){
  const draft=validateLocationDraft();
  if(!draft) return;
  state.location=draft.name;
  state.lat=String(draft.lat);
  state.lon=String(draft.lon);
  state.texts.location.value=draft.name.toLocaleUpperCase("de-DE");
  state.texts.coords.value=coordinatePosterText(draft.lat,draft.lon);
  document.getElementById("locationLabel").textContent=draft.name;
  updateQueryCoordinates();
  renderTextControls();
  safeRenderPortrait();
  setLiveStatus("","Standort aktualisiert","Live-Daten bei Bedarf neu laden.");
  document.getElementById("locationDialog")?.close();
}

let autoRefreshTimer=null;
function setAutoMode(enabled){
  if(autoRefreshTimer){
    window.clearInterval(autoRefreshTimer);
    autoRefreshTimer=null;
  }
  if(enabled){
    loadLiveAircraft().then(refreshMissingBases);
    autoRefreshTimer=window.setInterval(()=>loadLiveAircraft().then(refreshMissingBases),60000);
    setLiveStatus("loading","Automatik aktiv","Aktualisierung alle 60 Sekunden.");
  }else{
    setLiveStatus("","Automatik aus","Live-Flugzeuge können manuell geladen werden.");
  }
}

document.getElementById("exportBtn")?.addEventListener("click",exportPng);
document.getElementById("panelExportBtn")?.addEventListener("click",exportPanelBinary);
document.getElementById("changeLocationBtn")?.addEventListener("click",openLocationDialog);
document.getElementById("searchLocationBtn")?.addEventListener("click",validateLocationDraft);
document.getElementById("saveLocationBtn")?.addEventListener("click",saveLocation);
document.getElementById("closeLocationBtn")?.addEventListener("click",()=>document.getElementById("locationDialog")?.close());
document.getElementById("locationForm")?.addEventListener("submit",event=>{event.preventDefault();saveLocation();});
document.getElementById("radiusSelect")?.addEventListener("change",event=>{
  state.radius=Number(event.target.value);
  setLiveStatus("","Radius aktualisiert",`${state.radius} km · Live-Daten bei Bedarf neu laden.`);
});
document.getElementById("demoBtn")?.addEventListener("click",useDemoData);
document.getElementById("autoMode")?.addEventListener("change",event=>setAutoMode(event.target.checked));
document.querySelectorAll(".nav[data-target]").forEach(button=>button.addEventListener("click",()=>{
  document.querySelectorAll(".nav[data-target]").forEach(item=>item.classList.toggle("active",item===button));
  const target=button.dataset.target==="top" ? document.body : document.getElementById(button.dataset.target);
  target?.scrollIntoView({behavior:"smooth",block:"start"});
}));
window.addEventListener("beforeunload",()=>{
  if(autoRefreshTimer) window.clearInterval(autoRefreshTimer);
});



// V22.2 — observed missing base tracker and authenticated patch upload.
function formatSeenTimestamp(ts){
  if(!ts) return "–";
  try{return new Date(ts*1000).toLocaleString("de-DE");}catch(_){return "–";}
}

function patchToken(){
  return (document.getElementById("patchToken")?.value || "").trim();
}

function adminHeaders(extra={}){
  const token=patchToken();
  if(!token) throw new Error("Bitte zuerst den lokalen Administrations-Token eintragen.");
  return {...extra,"X-Aerofolio-Admin-Token":token};
}

async function patchMissingBase(type,file,row){
  const token=patchToken();
  if(!token){
    alert("Bitte zuerst den Patch-Token aus runtime/patch_token.txt eintragen.");
    return;
  }
  if(!file){
    alert(`Bitte eine PNG-Datei für ${type} auswählen.`);
    return;
  }
  if(file.type && file.type!=="image/png"){
    alert("Bitte ausschließlich PNG-Dateien verwenden.");
    return;
  }
  const status=row?.querySelector(".patch-result");
  if(status){status.textContent="Patch wird hochgeladen …";status.className="patch-result";}
  try{
    const raw=await file.arrayBuffer();
    const r=await fetch(`/api/library/patch?type=${encodeURIComponent(type)}`,{
      method:"POST",
      headers:{"Content-Type":"image/png","X-Aerofolio-Admin-Token":token},
      body:raw
    });
    const data=await r.json().catch(()=>({}));
    if(!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
    if(status){status.textContent=`✓ ${type} installiert`;status.className="patch-result patch-ok";}
    vintageProfileCache.clear();
    await refreshLibraryStatus();
    await refreshMissingBases();
    safeRenderPortrait();
  }catch(err){
    if(status){status.textContent=`✕ ${err.message}`;status.className="patch-result patch-error";}
  }
}

function renderMissingBases(rows){
  const el=document.getElementById("missingBaseList");
  if(!el) return;
  if(!rows?.length){
    el.innerHTML='<span class="muted">Aktuell keine fehlenden Live-Typen.</span>';
    return;
  }
  el.innerHTML=rows.map((m,i)=>{
    const ex=(m.examples||[])[(m.examples||[]).length-1]||{};
    const type=escapeHtml(m.type);
    const fallback=m.fallback?` · Fallback: ${escapeHtml(m.fallback)}`:"";
    const example=[ex.callsign,ex.registration,ex.operator].filter(Boolean).join(" · ");
    return `<div class="missing-base-row" data-missing-type="${type}">
      <div class="missing-base-row-top"><span class="missing-base-code">${type}</span><span class="muted">${Number(m.seen_count)||1}× gesehen</span></div>
      <div class="missing-base-meta">Zuletzt: ${escapeHtml(formatSeenTimestamp(m.last_seen))}${fallback}${example?`<br>${escapeHtml(example)}`:""}</div>
      <div class="missing-base-actions">
        <button class="ghost mini remote-base-btn" type="button" data-remote-state="unknown">Online prüfen</button>
        <input class="missing-file" type="file" accept="image/png">
        <button class="ghost mini patch-base-btn" type="button">PNG patchen</button>
      </div>
      <div class="remote-base-result missing-base-meta"></div>
      <div class="patch-result missing-base-meta"></div>
    </div>`;
  }).join("");
  el.querySelectorAll(".patch-base-btn").forEach(btn=>{
    btn.addEventListener("click",()=>{
      const row=btn.closest(".missing-base-row");
      const type=row.dataset.missingType;
      const file=row.querySelector(".missing-file")?.files?.[0];
      patchMissingBase(type,file,row);
    });
  });
  el.querySelectorAll(".remote-base-btn").forEach(btn=>{
    btn.addEventListener("click",()=>handleRemoteBaseButton(btn));
  });
}


let remoteBaseAvailability = new Map();

function applyRemoteBaseAvailability(items){
  remoteBaseAvailability = new Map((items||[]).map(x=>[String(x.code||"").toUpperCase(),x]));
  document.querySelectorAll(".missing-base-row").forEach(row=>{
    const code=String(row.dataset.missingType||"").toUpperCase();
    const item=remoteBaseAvailability.get(code);
    const btn=row.querySelector(".remote-base-btn");
    const result=row.querySelector(".remote-base-result");
    if(!btn) return;
    if(item?.available){
      btn.textContent="Base installieren";
      btn.dataset.remoteState="available";
      btn.disabled=false;
      if(result) result.textContent="✓ Auf GitHub verfügbar";
    }else{
      btn.textContent="Nicht online";
      btn.dataset.remoteState="missing";
      btn.disabled=true;
      if(result) result.textContent="Noch keine Base im zentralen Asset-Repository.";
    }
  });
}

async function checkRemoteBases(){
  const status=document.getElementById("remoteBaseStatus");
  const btn=document.getElementById("checkRemoteBases");
  if(status) status.textContent="Prüfe zentrale AEROFOLIO-Bibliothek…";
  if(btn) btn.disabled=true;
  try{
    const r=await fetch(`/api/assets/missing-availability?t=${Date.now()}`,{cache:"no-store"});
    const data=await r.json();
    if(!r.ok || !data.ok) throw new Error(data.error || `HTTP ${r.status}`);
    applyRemoteBaseAvailability(data.items||[]);
    const available=(data.items||[]).filter(x=>x.available).length;
    if(status) status.textContent=available
      ? `${available} fehlende Base${available===1?"":"s"} online verfügbar.`
      : "Keine der aktuell fehlenden Bases ist schon online verfügbar.";
  }catch(err){
    if(status) status.textContent=`Online-Prüfung fehlgeschlagen: ${err.message}`;
  }finally{
    if(btn) btn.disabled=false;
  }
}

async function handleRemoteBaseButton(btn){
  const row=btn.closest(".missing-base-row");
  if(!row) return;
  const code=String(row.dataset.missingType||"").toUpperCase();
  if(btn.dataset.remoteState!=="available"){
    await checkRemoteBases();
    if(btn.dataset.remoteState!=="available") return;
  }
  const result=row.querySelector(".remote-base-result");
  btn.disabled=true;
  if(result) result.textContent=`${code} wird sicher von GitHub geladen…`;
  try{
    const r=await fetch("/api/assets/install-missing",{
      method:"POST",
      headers:adminHeaders({"Content-Type":"application/json"}),
      body:JSON.stringify({codes:[code]})
    });
    const data=await r.json();
    if(!r.ok || !data.ok) throw new Error(data.errors?.[0]?.error || data.error || `HTTP ${r.status}`);
    if((data.installed||[]).length!==1) throw new Error("Base wurde online nicht gefunden.");
    vintageProfileCache.clear();
    if(result) result.textContent=`✓ ${code} installiert`;
    await refreshLibraryStatus();
    await refreshMissingBases();
    safeRenderPortrait();
  }catch(err){
    btn.disabled=false;
    if(result) result.textContent=`✕ ${err.message}`;
  }
}

async function refreshMissingBases(){
  try{
    const r=await fetch("/api/library/missing",{cache:"no-store"});
    if(!r.ok) return;
    const data=await r.json();
    renderMissingBases(data.missing||[]);
  }catch(_){ }
}

document.getElementById("refreshMissingBases")?.addEventListener("click",refreshMissingBases);
document.getElementById("checkRemoteBases")?.addEventListener("click",checkRemoteBases);

renderPlaneList();
renderStyles();
renderTextControls();
updateQueryCoordinates();
safeRenderPortrait();

refreshLibraryStatus();
refreshMissingBases();



function normalizeAerofolioVersion(value){
  const parts=String(value || "0").replace(/^v/i,"").split(".").map(n=>parseInt(n,10)||0);
  // Migration from legacy 23.2.x -> 0.23.2.x
  if(parts.length===3 && parts[0]>=10) return [0,...parts];
  return parts;
}

function compareVersions(a, b){
  const pa=normalizeAerofolioVersion(a);
  const pb=normalizeAerofolioVersion(b);
  const len=Math.max(pa.length,pb.length);
  for(let i=0;i<len;i++){
    const av=pa[i]||0, bv=pb[i]||0;
    if(av>bv) return 1;
    if(av<bv) return -1;
  }
  return 0;
}

async function checkForAerofolioUpdates(){
  const status = document.getElementById("updateStatus");
  const remote = document.getElementById("remoteVersion");
  const installed = document.getElementById("installedVersion");
  const btn = document.getElementById("checkUpdatesBtn");
  if(installed) installed.textContent = AEROFOLIO_VERSION;
  if(status) status.textContent = "Prüfe GitHub…";
  if(btn) btn.disabled = true;
  try{
    const response = await fetch("/api/update/check", {cache:"no-store"});
    const data = await response.json();
    if(!response.ok || data.error) throw new Error(data.error || `HTTP ${response.status}`);
    const latest = data.latest || "–";
    if(remote) remote.textContent = latest;
    const cmp = compareVersions(AEROFOLIO_VERSION, latest);
    if(status){
      if(cmp < 0){
        status.textContent = `Update ${latest} verfügbar.`;
        status.dataset.state = "available";
        ensureInstallUpdateButton();
        const ib=document.getElementById("installUpdateBtn"); if(ib) ib.style.display="block";
      }else if(cmp === 0){
        status.textContent = "AEROFOLIO ist aktuell.";
        status.dataset.state = "current";
      }else{
        status.textContent = "Lokale Version ist neuer als der Stable-Kanal.";
        status.dataset.state = "ahead";
      }
    }
  }catch(err){
    console.error("AEROFOLIO update check failed:", err);
    if(status){
      status.textContent = `Update-Prüfung fehlgeschlagen: ${err.message}`;
      status.dataset.state = "error";
    }
  }finally{
    if(btn) btn.disabled = false;
  }
}

window.addEventListener("DOMContentLoaded", ()=>{
  const btn = document.getElementById("checkUpdatesBtn");
  if(btn) btn.addEventListener("click", checkForAerofolioUpdates);
  const installed = document.getElementById("installedVersion");
  if(installed) installed.textContent = AEROFOLIO_VERSION;
});


async function installAerofolioUpdate(){
  const status=document.getElementById("updateStatus");
  const btn=document.getElementById("installUpdateBtn");
  let headers;
  try{
    headers=adminHeaders({"Cache-Control":"no-cache"});
  }catch(err){
    if(status) status.textContent=err.message;
    return;
  }
  if(!confirm("AEROFOLIO-Update jetzt installieren? Es wird vorher ein Backup angelegt.")) return;

  if(btn) btn.disabled=true;
  if(status) status.textContent="Update wird heruntergeladen und geprüft…";

  try{
    const response=await fetch(`/api/update/install?t=${Date.now()}`,{
      method:"POST",
      cache:"no-store",
      headers
    });

    const data=await response.json();
    if(!response.ok || !data.ok){
      throw new Error(data.error || `HTTP ${response.status}`);
    }

    if(status) status.textContent=
      `Update ${data.version} vorbereitet. AEROFOLIO beendet den alten Server und startet die neue Version…`;

    // From 0.23.2.7 onward the detached helper owns replacement + restart.
    await waitForAerofolioServer(70000, data.version);

    if(status) status.textContent=`Update ${data.version} erfolgreich. Oberfläche wird neu geladen…`;

    const freshUrl=new URL("/index.html",window.location.origin);
    freshUrl.searchParams.set("updated",data.version);
    freshUrl.searchParams.set("_",String(Date.now()));
    window.location.replace(freshUrl.toString());

  }catch(err){
    if(status) status.textContent=`Update fehlgeschlagen: ${err.message}`;
    if(btn) btn.disabled=false;
  }
}

async function waitForAerofolioServer(timeoutMs, expectedVersion){
  const started=Date.now();
  let lastSeen="";
  let lastPhase="";

  // Give the old process time to actually disappear before polling.
  await new Promise(r=>setTimeout(r,1800));

  while(Date.now()-started<timeoutMs){
    await new Promise(r=>setTimeout(r,850));

    try{
      const res=await fetch(`/api/update/status?t=${Date.now()}`,{
        cache:"no-store",
        headers:{"Cache-Control":"no-cache"}
      });
      if(!res.ok) continue;

      const data=await res.json();
      lastSeen=String(data.version||"");
      lastPhase=String(data.last_update?.phase||"");

      if(data.last_update?.ok===false &&
         ["rolled_back","rollback_failed","helper_failed"].includes(lastPhase)){
        throw new Error(
          data.last_update.error ||
          `Update wurde zurückgerollt (${lastPhase}).`
        );
      }

      if(compareVersions(lastSeen,expectedVersion)>=0 &&
         (!data.last_update || data.last_update.phase==="complete")){
        return true;
      }

    }catch(err){
      // A connection error is expected while the old server is down.
      // Explicit helper/rollback errors must still escape immediately.
      if(err?.message &&
         !/fetch|network|failed to fetch|load failed/i.test(err.message) &&
         /zurückgerollt|rollback|helper|Update wurde/i.test(err.message)){
        throw err;
      }
    }
  }

  throw new Error(
    lastSeen
      ? `Neuer Server nicht bestätigt. Zuletzt: ${lastSeen}${lastPhase?` (${lastPhase})`:""}.`
      : "Neuer Server wurde innerhalb von 70 Sekunden nicht erreichbar."
  );
}

function ensureInstallUpdateButton(){
  const check=document.getElementById("checkUpdatesBtn");
  if(!check || document.getElementById("installUpdateBtn")) return;
  const b=document.createElement("button");
  b.id="installUpdateBtn"; b.type="button"; b.textContent="Update installieren";
  b.style.display="none"; b.style.marginTop="8px";
  b.addEventListener("click",installAerofolioUpdate);
  check.insertAdjacentElement("afterend",b);
}
window.addEventListener("DOMContentLoaded",ensureInstallUpdateButton);

window.addEventListener("DOMContentLoaded",()=>{const uv=document.getElementById("uiVersion"); if(uv) uv.textContent=AEROFOLIO_VERSION;});


async function loadLastUpdateStatus(){
  try{
    const r=await fetch(`/api/update/status?t=${Date.now()}`,{cache:"no-store"});
    if(!r.ok) return;
    const data=await r.json();
    if(data?.last_update?.ok){
      const status=document.getElementById("updateStatus");
      if(status && data.last_update.version===AEROFOLIO_VERSION){
        status.textContent=`Zuletzt erfolgreich aktualisiert auf ${data.last_update.version}.`;
        status.dataset.state="current";
      }
    }
  }catch(_err){}
}
window.addEventListener("DOMContentLoaded",loadLastUpdateStatus);


(function cleanupPostUpdateUrl(){
  try{
    const url=new URL(window.location.href);
    if(url.searchParams.has("updated") || url.searchParams.has("_")){
      window.setTimeout(()=>{
        history.replaceState(null,"","/index.html");
      },1500);
    }
  }catch(_err){}
})();
