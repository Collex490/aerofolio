# AEROFOLIO 0.23.2.4

Neu:
- Doppelklick-Release-Publisher unter tools/
- Remote-Asset-Manifest API
- fehlende Bases können anhand ihrer Codes mit GitHub abgeglichen werden
- Asset-Download nur aus Collex490/aerofolio
- SHA-256-Prüfung vor Installation
- Assets werden getrennt vom System-Updater verwaltet

Hinweis:
Das Frontend für den automatischen Button zum Nachladen fehlender Bases wird im
nächsten Schritt an die bereits vorhandene Missing-Live-Bases-Kachel gekoppelt.
Die Server-API ist in dieser Version vorbereitet.
