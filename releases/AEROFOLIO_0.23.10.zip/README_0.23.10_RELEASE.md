# AEROFOLIO 0.23.10 – lokaler Release-Kandidat

Stand: 14. Oktober 2026

## Inhalt

- A20N, A21N, A319 und B738 durch neue, originale und markenfreie Basisillustrationen ersetzt
- exakte Bases für B77L und M20T ergänzt
- B77L-Fallback auf B772 entfernt
- M20T-Silhouette bei der Release-Sichtprüfung um die charakteristische vorwärts geneigte Heckflosse korrigiert
- Asset-Inventar auf 32 Bases ohne fehlende Typen, Warnungen oder Ersatzkandidaten gebracht

## Veröffentlichungshinweis

Das System-Update-ZIP enthält aus Sicherheits- und Bestandsschutzgründen keine Dateien aus `assets/`, `data/` oder `runtime/`. Die sechs Aircraft-Bases müssen deshalb getrennt über das geprüfte Asset-Manifest veröffentlicht werden. Erst danach dürfen das Systempaket und `latest.json` für `0.23.10` freigegeben werden.

Bis zur tatsächlichen Veröffentlichung bleibt `updates/latest.json` unverändert auf dem öffentlichen Stand `0.23.9`.

## Freigabeprüfungen

- strikter Asset-Validator
- Python-Testpaket einschließlich lokalem HTTP- und Security-Smoke-Test
- JavaScript-Syntaxprüfung
- Browser-Smoke-Test, sofern der optionale Browser-Harness verfügbar ist
- Paketbau ausschließlich mit `tools/build-release.ps1`
