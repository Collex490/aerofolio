# AEROFOLIO 0.23.2.5

## Update-System
- Windows-Neustart wurde robuster gemacht.
- Der alte Serverprozess beendet sich nach der Restart-Antwort gezielt.
- Ein abgekoppelter Helper wartet auf den freien Port und startet `server.py` neu.
- Diagnose landet in `runtime/restart.log`.
- Browser wartet weiterhin auf `/api/update/status`.

## Remote-Bases
- „Online prüfen“ in der Box „Fehlende Live-Bases“.
- Pro Typ wird angezeigt, ob eine Base im GitHub-Asset-Manifest verfügbar ist.
- Verfügbare Base lässt sich mit „Base installieren“ laden.
- Download nur aus `Collex490/aerofolio`.
- SHA-256 muss stimmen.
- Nach Installation wird `data/aircraft_mapping.json` automatisch ergänzt.
- Poster-Cache wird geleert und die Missing-Liste aktualisiert.

## Asset-Veröffentlichung
Unter `tools/`:
- `AEROFOLIO-ASSET-PUBLISH.bat`
- `publish-aircraft-base.ps1`

Damit kann eine neue `<ICAO>_base.png` per Doppelklick ins zentrale GitHub-Asset-Repository veröffentlicht werden.
