param(
    [Parameter(Mandatory = $true, Position = 0)][string]$PngPath,
    [Parameter(Mandatory = $true, Position = 1)][string]$Code,
    [string]$RepoRoot = $PSScriptRoot
)

$ErrorActionPreference = "Stop"
& (Join-Path $PSScriptRoot 'tools\publish-aircraft-base.ps1') -PngPath $PngPath -Code $Code -RepoRoot $RepoRoot
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
