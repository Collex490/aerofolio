@echo off
cd /d "%~dp0"
title AEROFOLIO
echo.
echo ==========================================
echo              AEROFOLIO
echo ==========================================
echo.
echo Starte lokalen Server...
echo Browser: http://localhost:8000
echo.
echo Dieses Fenster offen lassen.
echo.

set "AEROFOLIO_PYTHON="
for /f "delims=" %%P in ('where py 2^>nul ^& where python 2^>nul') do (
  if not defined AEROFOLIO_PYTHON (
    "%%P" -c "import sys" >nul 2>nul
    if not errorlevel 1 set "AEROFOLIO_PYTHON=%%P"
  )
)

if not defined AEROFOLIO_PYTHON (
  echo FEHLER: Keine funktionsfaehige Python-Installation gefunden.
  echo Bitte Python installieren oder den Windows-App-Ausfuehrungsalias korrigieren.
  goto :finished
)

start "" "http://localhost:8000/index.html"
"%AEROFOLIO_PYTHON%" server.py

:finished
echo.
pause
