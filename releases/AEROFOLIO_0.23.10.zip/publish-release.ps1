param(
    [Parameter(Mandatory = $true, Position = 0)][string]$ZipPath,
    [Parameter(Mandatory = $true, Position = 1)][string]$Version,
    [string]$RepoRoot = $PSScriptRoot
)

$ErrorActionPreference = "Stop"
& (Join-Path $PSScriptRoot 'tools\publish-release.ps1') -ZipPath $ZipPath -Version $Version -RepoRoot $RepoRoot
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
