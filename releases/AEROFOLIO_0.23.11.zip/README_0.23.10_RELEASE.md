# AEROFOLIO 0.23.10

Stand: 14. Oktober 2026

## Inhalt

- A20N, A21N, A319 und B738 durch neue, originale und markenfreie Basisillustrationen ersetzt
- exakte Bases für B77L und M20T ergänzt
- B77L-Fallback auf B772 entfernt
- M20T-Silhouette bei der Release-Sichtprüfung um die charakteristische vorwärts geneigte Heckflosse korrigiert
- Asset-Inventar auf 32 Bases ohne fehlende Typen, Warnungen oder Ersatzkandidaten gebracht

## Veröffentlichung

Das System-Update-ZIP enthält aus Sicherheits- und Bestandsschutzgründen keine Dateien aus `assets/`, `data/` oder `runtime/`. Die sechs Aircraft-Bases wurden deshalb zuerst getrennt über das geprüfte Asset-Manifest veröffentlicht. Danach folgten das Systempaket und `latest.json` für `0.23.10`.

- Asset-Commit: `7c0be0e`
- Release-Commit: `24b5d5680b93dbf9ef05d89e9dfa96489f5c6677`
- Paket: `AEROFOLIO_0.23.10.zip`, 37 Dateien
- SHA-256: `764A6FADD46600C23B83CBC1378D35619FFB8B931447CD774A0C35FBC4101E14`

Manifest, alle sechs Assets und das Paket wurden nach der Veröffentlichung erneut über ihre öffentlichen Raw-URLs heruntergeladen und bytegenau geprüft.

## Freigabeprüfungen

- strikter Asset-Validator
- Python-Testpaket einschließlich lokalem HTTP- und Security-Smoke-Test
- JavaScript-Syntaxprüfung
- Browser-Smoke-Test, sofern der optionale Browser-Harness verfügbar ist
- Paketbau ausschließlich mit `tools/build-release.ps1`
