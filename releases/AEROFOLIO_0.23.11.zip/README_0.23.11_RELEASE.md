# AEROFOLIO 0.23.11 – Health-Hotfix

Stand: 14. Oktober 2026

## Änderung

- `/api/health` meldet nicht mehr die veraltete feste Bezeichnung `AEROFOLIO V22.2`.
- Der Endpunkt liefert jetzt den stabilen Servicenamen `AEROFOLIO` und die tatsächlich aus `data/version.json` gelesene installierte Version.
- Der lokale HTTP-Test prüft Servicename und Version ausdrücklich, damit die Angabe nicht erneut unbemerkt veraltet.

## Freigabeprüfungen

- vollständiges Python-Testpaket einschließlich lokalem HTTP- und Security-Smoke-Test
- JavaScript-Syntaxprüfung und Frontend-Versionsvertrag
- lokaler Start und `/api/health`
- Paketbau und Paketprüfung ausschließlich mit `tools/build-release.ps1`
